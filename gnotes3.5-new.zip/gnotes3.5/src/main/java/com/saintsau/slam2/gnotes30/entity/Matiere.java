package com.saintsau.slam2.gnotes30.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.Set;

@Entity
@Table(name = "matieres")
public class Matiere {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "intitule", nullable = false)
    private String intitule;

    @OneToMany(mappedBy = "matiere", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnore
    private Set<Controle> controles;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "etudiant_id")
    private Etudiant etudiant;

    @Column(name = "type")
    private String type;

    @Column(name = "coef")
    private int coef;

    @Column(name = "note")
    private float note;

	private Professor professor;

    // Constructeurs
    public Matiere(String intitule, String type, int coef, float note) {
        this.intitule = intitule;
        this.type = type;
        this.coef = coef;
        this.note = note;
    }

    public Matiere() {}

    // Getters et setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }

    public Set<Controle> getControles() {
        return controles;
    }

    public void setControles(Set<Controle> controles) {
        this.controles = controles;
    }

    public Etudiant getEtudiant() {
        return etudiant;
    }

    public void setEtudiant(Etudiant etudiant) {
        this.etudiant = etudiant;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCoef() {
        return coef;
    }

    public void setCoef(int coef) {
        this.coef = coef;
    }

    public float getNote() {
        return note;
    }

    public void setNote(float note) {
        this.note = note;
    }

    // Méthode pour calculer la moyenne des notes pour cette matière
    public float calculerMoyenne() {
        if (controles == null || controles.isEmpty()) {
            return 0;
        }

        int sumCoef = 0;
        float sumNotes = 0;

        for (Controle controle : controles) {
            sumNotes += controle.getNote() * controle.getCoefficient();
            sumCoef += controle.getCoefficient();
        }

        return sumCoef > 0 ? Math.round((sumNotes / sumCoef) * 100) / 100.0f : 0;
    }

    @Override
    public String toString() {
        return "Matiere [intitule=" + intitule + ", moyenne=" + calculerMoyenne() + "]";
    }

 // Modification de la méthode setProfessor
    public void setProfessor(Professor professor) {
        // Éviter de définir un professeur null
        if (this.professor != null) {
            // Si la matière a déjà un professeur, il faut retirer cette matière de la liste des matières du professeur précédent
            this.professor.getSubjects().remove(this);
        }

        // Associer cette matière au nouveau professeur
        this.professor = professor;

        if (professor != null) {
            // Ajouter cette matière à la liste des matières du professeur
            professor.getSubjects().add(this);
        }
}
}
