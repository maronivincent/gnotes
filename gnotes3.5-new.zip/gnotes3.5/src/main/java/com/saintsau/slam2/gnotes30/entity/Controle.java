package com.saintsau.slam2.gnotes30.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "controles")
public class Controle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "etudiant_id", nullable = false)
    private Etudiant etudiant;

    @ManyToOne
    @JoinColumn(name = "matiere_id", nullable = false)
    private Matiere matiere;

    @Column(name = "professeur_username", nullable = false)
    private String professeurUsername; // Identifie le professeur

    @Column(name = "coefficient", nullable = false)
    private int coefficient;

    @Column(name = "type", nullable = false)
    private String type; // Ex: "DS", "Oral", "TP"

    @Column(name = "note", nullable = false)
    private float note;

    @Column(name = "date_controle", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dateControle;

    // Constructeurs
    public Controle() {}

    public Controle(Etudiant etudiant, Matiere matiere, String professeurUsername, int coefficient, String type, float note, Date dateControle) {
        this.etudiant = etudiant;
        this.matiere = matiere;
        this.professeurUsername = professeurUsername;
        this.coefficient = coefficient;
        this.type = type;
        this.note = note;
        this.dateControle = dateControle;
    }

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Etudiant getEtudiant() {
        return etudiant;
    }

    public void setEtudiant(Etudiant etudiant) {
        this.etudiant = etudiant;
    }

    public Matiere getMatiere() {
        return matiere;
    }

    public void setMatiere(Matiere matiere) {
        this.matiere = matiere;
    }

    public String getProfesseurUsername() {
        return professeurUsername;
    }

    public void setProfesseurUsername(String professeurUsername) {
        this.professeurUsername = professeurUsername;
    }

    public int getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(int coefficient) {
        this.coefficient = coefficient;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public float getNote() {
        return note;
    }

    public void setNote(float note) {
        this.note = note;
    }

    public Date getDateControle() {
        return dateControle;
    }

    public void setDateControle(Date dateControle) {
        this.dateControle = dateControle;
    }

    @Override
    public String toString() {
        return "Controle [id=" + id + ", etudiant=" + etudiant.getNom() + " " + etudiant.getPrenom() +
                ", matiere=" + matiere.getIntitule() + ", professeur=" + professeurUsername +
                ", type=" + type + ", coefficient=" + coefficient + ", note=" + note +
                ", date=" + dateControle + "]";
    }
}
