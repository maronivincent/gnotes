package com.saintsau.slam2.gnotes30.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import jakarta.persistence.*;

@Entity
@Table(name = "etudiants")
public class Etudiant {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  // Remplace "numero" par "id"

    @Column(name = "nom", nullable = false)
    private String nom;

    @Column(name = "prenom", nullable = false)
    private String prenom;  

    @OneToMany(mappedBy = "etudiant", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Matiere> matieres = new ArrayList<>();  // Ajout de la liste de Matieres

    // Constructeurs
    public Etudiant(String nom, String prenom, Long id) {
        this.nom = nom;
        this.prenom = prenom;
        this.id = id;
    }

    public Etudiant(String nom, String prenom) {
        this.nom = nom;
        this.prenom = prenom;
    }

    public Etudiant() {}

    // Getters et setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    // Méthode pour obtenir le numéro (équivalent à l'id)
    public Long getNumero() {
        return id;  // Retourne l'id comme numéro de l'étudiant
    }

    // Méthode pour obtenir les matieres de l'étudiant
    public List<Matiere> getMatieres() {
        return matieres;  // Retourne la liste des matières
    }

    // Méthode pour afficher les informations sur l'étudiant
    @Override
    public String toString() {
        return "Etudiant [nom=" + nom + ", prénom=" + prenom + ", id=" + id + "]";
    }

    // Méthode pour calculer la moyenne à partir d'une liste de contrôles
    public float calculerMoyenne(List<Controle> controles) {
        int sumCoef = 0;
        float sumMatiere = 0;

        for (Controle controle : controles) {
            sumMatiere += controle.getNote() * controle.getCoefficient();
            sumCoef += controle.getCoefficient();
        }

        return sumCoef > 0 ? Math.round((sumMatiere / sumCoef) * 100) / 100.0f : 0;
    }

    // Méthode pour obtenir les majors de la promotion
    public static List<Etudiant> majorDePromotion(List<Etudiant> etudiants, List<Controle> controles) {
        float moyenneMajor = 0;
        List<Etudiant> majors = new ArrayList<>();

        for (Etudiant etudiant : etudiants) {
            float moyenneEtudiant = etudiant.calculerMoyenne(
                controles.stream().filter(c -> c.getEtudiant().equals(etudiant)).toList()
            );

            if (moyenneMajor < moyenneEtudiant) {
                majors.clear();
                majors.add(etudiant);
                moyenneMajor = moyenneEtudiant;
            } else if (moyenneMajor == moyenneEtudiant) {
                majors.add(etudiant);
            }
        }

        return majors;
    }

    public void setMatieres(Set<Matiere> matieres) {
        // Si tu veux convertir le Set en List, voici la conversion
        this.matieres = new ArrayList<>(matieres);

        // On associe chaque matière à cet étudiant
        for (Matiere matiere : matieres) {
            matiere.setEtudiant(this);  // Associe cet étudiant à chaque matière
        }
    }

    public void setNumero(long l) {
        this.id = l;  // Assigner la valeur de l à l'attribut id
    }


}
