package com.saintsau.slam2.gnotes30.repository;

import com.saintsau.slam2.gnotes30.entity.Professor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfessorRepository extends JpaRepository<Professor, Long> {
    // Custom queries can be added here if needed
}
