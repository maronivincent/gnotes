package com.saintsau.slam2.gnotes30.controller;

import com.saintsau.slam2.gnotes30.entity.Professor;
import com.saintsau.slam2.gnotes30.entity.Matiere;
import com.saintsau.slam2.gnotes30.service.ProfessorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/professors")
public class ProfessorController {

    @Autowired
    private ProfessorService professorService;

    // Endpoint to create a new professor
    @PostMapping
    public Professor createProfessor(@RequestBody Professor professor) {
        return professorService.createProfessor(professor.getFirstName(), professor.getLastName(), professor.getEmail());
    }

    // Endpoint to add a subject to a professor
    @PostMapping("/{professorId}/subjects")
    public Professor addSubjectToProfessor(@PathVariable Long professorId, @RequestBody Matiere matiere) {
        return professorService.addSubjectToProfessor(professorId, matiere);
    }

    // Endpoint to remove a subject from a professor
    @DeleteMapping("/{professorId}/subjects")
    public Professor removeSubjectFromProfessor(@PathVariable Long professorId, @RequestBody Matiere matiere) {
        return professorService.removeSubjectFromProfessor(professorId, matiere);
    }
}
