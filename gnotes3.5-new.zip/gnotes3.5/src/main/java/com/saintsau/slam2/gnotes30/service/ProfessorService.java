package com.saintsau.slam2.gnotes30.service;

import com.saintsau.slam2.gnotes30.entity.Professor;
import com.saintsau.slam2.gnotes30.entity.Matiere;
import com.saintsau.slam2.gnotes30.repository.ProfessorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProfessorService {

    @Autowired
    private ProfessorRepository professorRepository;

    // Create a new professor
    public Professor createProfessor(String firstName, String lastName, String email) {
        Professor professor = new Professor(firstName, lastName, email);
        return professorRepository.save(professor);
    }

    // Add a subject to a professor
    public Professor addSubjectToProfessor(Long professorId, Matiere matiere) {
        Professor professor = professorRepository.findById(professorId).orElseThrow(() -> new IllegalArgumentException("Professor not found"));
        professor.addSubject(matiere);
        return professorRepository.save(professor);
    }

    // Remove a subject from a professor
    public Professor removeSubjectFromProfessor(Long professorId, Matiere matiere) {
        Professor professor = professorRepository.findById(professorId).orElseThrow(() -> new IllegalArgumentException("Professor not found"));
        professor.removeSubject(matiere);
        return professorRepository.save(professor);
    }
}
