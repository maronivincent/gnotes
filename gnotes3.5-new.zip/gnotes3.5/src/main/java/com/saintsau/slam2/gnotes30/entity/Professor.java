package com.saintsau.slam2.gnotes30.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Professor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String firstName;
    private String lastName;
    private String email;

    @OneToMany(mappedBy = "professor", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Matiere> subjects = new HashSet<>();

    // Constructor
    public Professor(String firstName, String lastName, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
    }

    public Professor() {
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Set<Matiere> getSubjects() {
        return subjects;
    }

    public void setSubjects(Set<Matiere> subjects) {
        this.subjects = subjects;
    }

    // Methods for adding and removing subjects
    public void addSubject(Matiere subject) {
        subjects.add(subject);
        subject.setProfessor(this); // Linking subject to professor
    }

    public void removeSubject(Matiere subject) {
        subjects.remove(subject);
        subject.setProfessor(null); // Removing the link to professor
    }
}
