package com.saintsau.slam2.gnotes30.service;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.saintsau.slam2.gnotes30.entity.Etudiant;
import com.saintsau.slam2.gnotes30.entity.Matiere;
import com.saintsau.slam2.gnotes30.exeption.EtudiantNotFoundException;
import com.saintsau.slam2.gnotes30.exeption.MatiereNotFoundException;
import com.saintsau.slam2.gnotes30.jpaRepository.EtudiantRepository;

@Service
public class EtudiantService {
    
    private final EtudiantRepository etudiantRepository;

    public EtudiantRepository getEtudiantRepository() {
        return etudiantRepository;
    }

    EtudiantService(EtudiantRepository etudiantRepository){
        super();
        this.etudiantRepository = etudiantRepository;
    }

    public Etudiant saveEtudiant(Etudiant etudiant) {
        return etudiantRepository.save(etudiant); 
    }

    public List<Etudiant> findAllEtudiant() {
        return (List<Etudiant>) etudiantRepository.findAll(); 
    }

    public Etudiant findEtudiantById(Long id) {
        return etudiantRepository.findById(id)
                .orElseThrow(() -> new EtudiantNotFoundException(id));
    }

    public Etudiant saveMatiereByEtudiant(Long idEtudiant, Set<Matiere> matieres) {
        Etudiant etudiant = etudiantRepository.findById(idEtudiant)
                .orElseThrow(() -> new EtudiantNotFoundException(idEtudiant));
        
        // Ajout des matières à l'étudiant
        for(Matiere matiere : matieres){
            matiere.setEtudiant(etudiant); // Associe chaque matière à l'étudiant
        }
        
        // Met à jour les matières de l'étudiant
        etudiant.setMatieres(matieres);
        
        // Sauvegarde l'étudiant avec ses matières
        return etudiantRepository.save(etudiant);
    }

    @SuppressWarnings("unchecked")
	public Set<Matiere> findAllMatiereByEtudiant(long idEtudiant) {
        Etudiant etudiant = etudiantRepository.findById(idEtudiant)
                .orElseThrow(() -> new EtudiantNotFoundException(idEtudiant));
        return (Set<Matiere>) etudiant.getMatieres(); // Retourne les matières associées à l'étudiant
    }

    public Matiere findMatiereById(long idEtudiant, long idMatiere) {
        Etudiant etudiant = etudiantRepository.findById(idEtudiant)
                .orElseThrow(() -> new EtudiantNotFoundException(idEtudiant));
        
        // Recherche la matière dans les matières de l'étudiant
        Set<Matiere> matieres = (Set<Matiere>) etudiant.getMatieres();
        for(Matiere matiere : matieres){
            if(matiere.getId() == idMatiere) {
                return matiere;
            }
        }
        
        // Si la matière n'est pas trouvée
        throw new MatiereNotFoundException(idMatiere);
    }

    public Etudiant deleteById(Long id) {
        // Récupère l'étudiant à supprimer
        Etudiant etudiant = etudiantRepository.findById(id)
                .orElseThrow(() -> new EtudiantNotFoundException(id));

        // Supprime l'étudiant
        etudiantRepository.deleteById(id);

        // Retourne l'étudiant supprimé
        return etudiant;
    }

    public Etudiant updateEtudiant(Long id, Etudiant updatedEtudiant) {
        Etudiant etudiant = etudiantRepository.findById(id)
            .orElseThrow(() -> new EtudiantNotFoundException(id));

        // Mise à jour des champs de l'étudiant (par exemple : nom, prénom, etc.)
        etudiant.setNom(updatedEtudiant.getNom());
        etudiant.setPrenom(updatedEtudiant.getPrenom()); // Ajout de la mise à jour du prénom si nécessaire
        
        return etudiantRepository.save(etudiant);
    }

    public Etudiant updateMatiere(Long idEtudiant, Long idMatiere, Matiere updatedMatiere) {
        Etudiant etudiant = etudiantRepository.findById(idEtudiant)
            .orElseThrow(() -> new EtudiantNotFoundException(idEtudiant));

        // Trouve la matière spécifique à mettre à jour
        Matiere matiereToUpdate = null;
        for (Matiere matiere : etudiant.getMatieres()) {
            if (matiere.getId() == idMatiere) {
                matiereToUpdate = matiere;
                break;
            }
        }

        if (matiereToUpdate == null) {
            throw new MatiereNotFoundException(idMatiere);
        }

        // Mise à jour des champs de la matière
        matiereToUpdate.setIntitule(updatedMatiere.getIntitule());
        matiereToUpdate.setType(updatedMatiere.getType());
        matiereToUpdate.setCoef(updatedMatiere.getCoef());
        matiereToUpdate.setNote(updatedMatiere.getNote());

        // Sauvegarde l'étudiant avec les matières mises à jour
        return etudiantRepository.save(etudiant);
    }

    public Etudiant deleteMatiere(Long idEtudiant, Long idMatiere) {
        Etudiant etudiant = etudiantRepository.findById(idEtudiant)
            .orElseThrow(() -> new EtudiantNotFoundException(idEtudiant));

        // Recherche de la matière à supprimer
        Matiere matiereToRemove = null;
        for (Matiere matiere : etudiant.getMatieres()) {
            if (matiere.getId() == idMatiere) {
                matiereToRemove = matiere;
                break;
            }
        }

        if (matiereToRemove == null) {
            throw new MatiereNotFoundException(idMatiere);
        }

        // Retire la matière de l'étudiant
        etudiant.getMatieres().remove(matiereToRemove); // Retire la matière du set

        // Sauvegarde l'étudiant avec ses matières mises à jour
        return etudiantRepository.save(etudiant);
    }
}
