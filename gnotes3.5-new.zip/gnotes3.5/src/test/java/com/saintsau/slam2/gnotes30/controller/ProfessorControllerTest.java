package com.saintsau.slam2.gnotes30.controller;

import com.saintsau.slam2.gnotes30.entity.Professor;
import com.saintsau.slam2.gnotes30.entity.Matiere;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
public class ProfessorControllerTest {

    @Autowired
    private ProfessorController professorController;

    private MockMvc mockMvc;

    @BeforeEach
    void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(professorController).build();
    }

    @Test
    void testCreateProfessor() throws Exception {
        mockMvc.perform(post("/api/professors")
                .contentType("application/json")
                .content("{\"firstName\":\"John\", \"lastName\":\"Doe\", \"email\":\"john.doe@example.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName").value("John"));
    }

    @Test
    void testAddSubjectToProfessor() throws Exception {
        Matiere matiere = new Matiere("Maths", "Exam", 3, 0);
        mockMvc.perform(post("/api/professors/1/subjects")
                .contentType("application/json")
                .content("{\"title\":\"Maths\", \"type\":\"Exam\", \"credits\":3}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.subjects").isNotEmpty());
    }

    @Test
    void testRemoveSubjectFromProfessor() throws Exception {
        Matiere matiere = new Matiere("Maths", "Exam", 3, 0);
        mockMvc.perform(delete("/api/professors/1/subjects")
                .contentType("application/json")
                .content("{\"title\":\"Maths\", \"type\":\"Exam\", \"credits\":3}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.subjects").isEmpty());
    }
}
