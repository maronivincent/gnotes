package com.saintsau.slam2.gnotes30.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.saintsau.slam2.gnotes30.entity.Etudiant;
import com.saintsau.slam2.gnotes30.entity.Matiere;

@SpringBootTest
public class EtudiantServiceTest {
    
    @Autowired
    EtudiantService etudiantService;
    
    // Méthode pour créer des matières associées à un étudiant
    private Set<Matiere> createMatieresForEtudiant(float etudiant) {
        Set<Matiere> matieres = new HashSet<>();
        matieres.add(new Matiere("Maths", "Devoir ecrit", 3, etudiant));
        matieres.add(new Matiere("Physique", "TP", 4, etudiant));
        matieres.add(new Matiere("Français", "Eval Orale", 2, etudiant));
        matieres.add(new Matiere("Histoire", "Eval Orale", 2, etudiant));
        matieres.add(new Matiere("SVT", "TP", 3, etudiant));
        return matieres;
    }
    
    @BeforeEach
    void testInitialize() {
        etudiantService.getEtudiantRepository().deleteAll(); // Reset the database before each test
    }
    
    @Test
    public void testSaveEtudiant() {
        // Given
        Etudiant dimitri = new Etudiant("Dimitri", "Dupont");
        
        // When
        Etudiant savedEtudiant = etudiantService.saveEtudiant(dimitri);
        
        // Then
        assertThat(savedEtudiant.getNom()).isEqualTo("Dimitri");
        assertThat(savedEtudiant.getPrenom()).isEqualTo("Dupont");
    }
    
    @Test
    public void testFindAllEtudiant() {
        // Given
        Etudiant dimitri = new Etudiant("Dimitri", "Dupont");
        Etudiant jean = new Etudiant("Jean", "Marin");
        Etudiant lea = new Etudiant("Lea", "Lemoine");
        
        // When
        etudiantService.saveEtudiant(dimitri);
        etudiantService.saveEtudiant(jean);
        etudiantService.saveEtudiant(lea);
        
        List<Etudiant> allEtudiants = etudiantService.findAllEtudiant();
        
        // Then
        assertThat(allEtudiants).hasSize(3);
        assertThat(allEtudiants).extracting(Etudiant::getNom)
            .containsExactlyInAnyOrder("Dimitri", "Jean", "Lea");
    }
    
    @Test
    public void testFindEtudiantById() {
        // This test is non-testable as stated in the comment.
        // Ideally, you would test this by mocking the database behavior or providing a valid id to fetch the student.
    }
    
    @Test
    public void testNewMatierePerEtudiant() {
        // Given
        Etudiant dimitri = new Etudiant("Dimitri", "Dupont");
        Set<Matiere> matieresDimitri = createMatieresForEtudiant(dimitri);
        dimitri.setMatieres(matieresDimitri);
        
        // When
        dimitri = etudiantService.saveMatiereByEtudiant(dimitri.getNumero(), matieresDimitri);
        
        // Then
        assertThat(dimitri.getMatieres()).hasSize(5);
        assertThat(dimitri.getMatieres()).extracting(Matiere::getIntitule)
            .containsExactlyInAnyOrder("Maths", "Physique", "Français", "Histoire", "SVT");
    }
    
    private Set<Matiere> createMatieresForEtudiant(Etudiant dimitri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Test
    public void testGetMatieresByEtudiant() {
        // Given
        Etudiant dimitri = new Etudiant("Dimitri", "Dupont");
        Set<Matiere> matieresDimitri = createMatieresForEtudiant(dimitri);
        dimitri.setMatieres(matieresDimitri);
        dimitri = etudiantService.saveEtudiant(dimitri);
        
        // When
        List<Matiere> matieres = new ArrayList<>(dimitri.getMatieres());
        
        // Then
        assertThat(matieres).hasSize(5);
        assertThat(matieres).extracting(Matiere::getIntitule)
            .containsExactlyInAnyOrder("Maths", "Physique", "Français", "Histoire", "SVT");
    }
}
