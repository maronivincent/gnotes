package com.saintsau.slam2.gnotes30.jpaRepository;

import org.springframework.data.repository.CrudRepository;

import com.saintsau.slam2.gnotes30.entity.Controle;

/**
 * Interface de dépôt (repository) pour gérer les entités `Controle`.
 * Cette interface étend `CrudRepository` et permet d'effectuer des opérations CRUD sur les entités `Controle`.
 */
public interface ControleRepository extends CrudRepository<Controle, Long> {

    /**
     * Recherche un `Controle` par son identifiant.
     * 
     * @param id L'identifiant du contrôle à rechercher.
     * @return Un objet `Controle` correspondant à l'identifiant donné.
     * Si l'entité n'est pas trouvée, il renvoie `null`.
     */
    Controle findById(long id);
}
