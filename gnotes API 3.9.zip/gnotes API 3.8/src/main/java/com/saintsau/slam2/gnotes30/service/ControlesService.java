package com.saintsau.slam2.gnotes30.service;

import com.saintsau.slam2.gnotes30.entity.Controle;
import com.saintsau.slam2.gnotes30.exeption.ControleNotFoundExeption;
import com.saintsau.slam2.gnotes30.jpaRepository.ControleRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service qui gère les opérations liées aux contrôles.
 * Ce service fournit des méthodes pour effectuer des opérations CRUD sur les entités `Controle`.
 */
@Service
public class ControlesService {

   private final ControleRepository controleRepository;

   /**
    * Constructeur du service `ControlesService`.
    * 
    * @param controleRepository Le dépôt qui gère les entités `Controle`.
    */
   ControlesService(ControleRepository controleRepository){
    	super();
    	this.controleRepository = controleRepository;
   }

   /**
    * Récupère la référence au dépôt des contrôles.
    * 
    * @return Le dépôt des contrôles.
    */
   public ControleRepository getControleRepository() {
    	return controleRepository;
   }
    
   /**
    * Récupère tous les contrôles enregistrés dans la base de données.
    * 
    * @return Une liste contenant tous les contrôles.
    */
   public List<Controle> getAllControles() {
        return (List<Controle>) controleRepository.findAll();
   }
    
   /**
    * Récupère un contrôle spécifique par son identifiant.
    * Si le contrôle n'existe pas, une exception `ControleNotFoundExeption` est levée.
    * 
    * @param id L'identifiant du contrôle à rechercher.
    * @return Le contrôle correspondant à l'identifiant.
    * @throws ControleNotFoundExeption Si le contrôle avec l'identifiant donné n'est pas trouvé.
    */
   public Controle getContoleById(Long id) {
	   return controleRepository.findById(id)
			   .orElseThrow(() -> new ControleNotFoundExeption(id));
   }
   
   /**
    * Crée un nouveau contrôle dans la base de données.
    * 
    * @param controle Le contrôle à créer.
    * @return Le contrôle créé avec son identifiant généré.
    */
   public Controle saveControle(Controle controle) {
       return controleRepository.save(controle);
   }
   
   /**
    * Met à jour un contrôle existant dans la base de données.
    * Si le contrôle avec l'identifiant spécifié n'existe pas, une exception `ControleNotFoundExeption` est levée.
    * 
    * @param id L'identifiant du contrôle à mettre à jour.
    * @param updatedControle Les nouvelles informations pour le contrôle.
    * @return Le contrôle mis à jour.
    * @throws ControleNotFoundExeption Si le contrôle avec l'identifiant donné n'est pas trouvé.
    */
   public Controle updateControle(Long id, Controle updatedControle) {
	   Controle controle = controleRepository.findById(id)
			   .orElseThrow(() -> new ControleNotFoundExeption(id));
	   controle.setEtudiant(updatedControle.getEtudiant());
       controle.setProfesseur(updatedControle.getProfesseur());
       controle.setMatiere(updatedControle.getMatiere());
       controle.setCoefficient(updatedControle.getCoefficient());
       controle.setType(updatedControle.getType());
       controle.setNote(updatedControle.getNote());
       controle.setDateControle(updatedControle.getDateControle());
       
       return controleRepository.save(controle);
   }
   
   /**
    * Supprime un contrôle de la base de données par son identifiant.
    * Si le contrôle n'existe pas, une exception `ControleNotFoundExeption` est levée.
    * 
    * @param id L'identifiant du contrôle à supprimer.
    * @return Le contrôle supprimé.
    * @throws ControleNotFoundExeption Si le contrôle avec l'identifiant donné n'est pas trouvé.
    */
   public Controle deleteControle(Long id) {
	   Controle controle = controleRepository.findById(id)
			   .orElseThrow(() -> new ControleNotFoundExeption(id));
	   controleRepository.deleteById(id);
	   
	   return controle;
   }
}
