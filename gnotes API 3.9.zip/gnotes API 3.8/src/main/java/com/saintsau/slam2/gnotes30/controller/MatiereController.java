package com.saintsau.slam2.gnotes30.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.saintsau.slam2.gnotes30.entity.Matiere;
import com.saintsau.slam2.gnotes30.service.MatiereService;

/**
 * Contrôleur REST pour gérer les opérations liées aux matières.
 * Fournit des méthodes pour ajouter, récupérer, mettre à jour et supprimer des matières.
 * Utilise HATEOAS pour l'intégration des liens dans les réponses.
 */
@RestController
public class MatiereController {

    private final MatiereService matiereService;

    /**
     * Constructeur de la classe {@link MatiereController}.
     *
     * @param matiereService Le service utilisé pour gérer les matières
     */
    public MatiereController(MatiereService matiereService) {
        this.matiereService = matiereService;
    }

    /**
     * Crée une nouvelle matière dans la base de données.
     *
     * @param matiere L'objet Matiere à ajouter
     * @return Un modèle contenant la matière ajoutée avec des liens HATEOAS
     */
    @PostMapping("/matieres")
    public EntityModel<Matiere> newMatiere(@RequestBody Matiere matiere) {
        Matiere savedMatiere = matiereService.saveMatiere(matiere);

        return EntityModel.of(savedMatiere,
                linkTo(methodOn(MatiereController.class).getMatiereById(savedMatiere.getId())).withSelfRel(),
                linkTo(methodOn(MatiereController.class).all()).withRel("matieres"));
    }

    /**
     * Récupère toutes les matières dans la base de données.
     *
     * @return Une collection de matières sous forme de modèles avec des liens HATEOAS
     */
    @GetMapping("/matieres")
    public CollectionModel<EntityModel<Matiere>> all() {
        List<EntityModel<Matiere>> matieres = StreamSupport.stream(matiereService.findAllMatiere().spliterator(), false)
                .map((Matiere matiere) -> EntityModel.of(matiere,
                        linkTo(methodOn(MatiereController.class).getMatiereById(matiere.getId())).withSelfRel()))
                .collect(Collectors.toList());

        return CollectionModel.of(matieres,
                linkTo(methodOn(MatiereController.class).all()).withSelfRel());
    }

    /**
     * Récupère une matière spécifique en fonction de son identifiant.
     *
     * @param id L'ID de la matière à récupérer
     * @return Un modèle contenant la matière trouvée avec des liens HATEOAS
     * @throws MatiereNotFoundException Si la matière n'est pas trouvée
     */
    @GetMapping("/matieres/{id}")
    public EntityModel<Matiere> getMatiereById(@PathVariable Long id) {
        Matiere matiere = matiereService.getMatiereById(id);

        return EntityModel.of(matiere,
                linkTo(methodOn(MatiereController.class).getMatiereById(id)).withSelfRel(),
                linkTo(methodOn(MatiereController.class).all()).withRel("matieres"));
    }

    /**
     * Met à jour les informations d'une matière existante.
     *
     * @param id             L'ID de la matière à mettre à jour
     * @param updatedMatiere L'objet Matiere contenant les nouvelles informations
     * @return Un modèle contenant la matière mise à jour avec des liens HATEOAS
     * @throws MatiereNotFoundException Si la matière n'est pas trouvée
     */
    @PutMapping("/matieres/{id}")
    public EntityModel<Matiere> updateMatiere(@PathVariable Long id, @RequestBody Matiere updatedMatiere) {
        Matiere matiere = matiereService.updateMatiere(id, updatedMatiere);

        return EntityModel.of(matiere,
                linkTo(methodOn(MatiereController.class).getMatiereById(matiere.getId())).withSelfRel(),
                linkTo(methodOn(MatiereController.class).all()).withRel("matieres"));
    }

    /**
     * Supprime une matière spécifique en fonction de son identifiant.
     *
     * @param id L'ID de la matière à supprimer
     * @return Un modèle contenant un message de confirmation et des liens HATEOAS
     * @throws MatiereNotFoundException Si la matière n'est pas trouvée
     */
    @DeleteMapping("/matieres/{id}")
    public EntityModel<Map<String, Object>> deleteMatiere(@PathVariable Long id) {
        Matiere deletedMatiere = matiereService.deleteMatiere(id);

        String message = "Matière supprimée: " + deletedMatiere.getIntitule();

        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        response.put("matiere", deletedMatiere);

        return EntityModel.of(response,
                linkTo(methodOn(MatiereController.class).all()).withRel("matieres"));
    }
}
