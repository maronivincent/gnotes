package com.saintsau.slam2.gnotes30.entity;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

/**
 * Représente un utilisateur dans le système. Cette classe contient des informations sur 
 * l'utilisateur telles que son nom d'utilisateur, son mot de passe, son statut (activé ou non)
 * et la liste des contrôles associés à cet utilisateur (en tant que professeur).
 * 
 * Cette classe est mappée à la table `users` dans la base de données.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "users")
public class User {

    /**
     * Clé primaire unique de l'utilisateur.
     */
    private Long id;

    /**
     * Nom d'utilisateur unique pour l'utilisateur (identifiant).
     */
    private String username;

    /**
     * Mot de passe de l'utilisateur, stocké de manière sécurisée.
     */
    private String password;

    /**
     * Statut activé de l'utilisateur. Indique si l'utilisateur est actif ou désactivé.
     */
    private boolean enabled;

    /**
     * Liste des contrôles associés au professeur (utilisateur).
     */
    private Set<Controle> controles;

    /**
     * Constructeur par défaut pour créer une instance d'un utilisateur sans initialisation.
     */
    public User() {
        super();
    }

    /**
     * Constructeur pour initialiser un utilisateur avec un nom d'utilisateur, un mot de passe et un statut activé.
     *
     * @param username Le nom d'utilisateur unique.
     * @param password Le mot de passe de l'utilisateur.
     * @param enabled  Le statut activé de l'utilisateur (true si l'utilisateur est activé).
     */
    public User(String username, String password, boolean enabled) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
    }
    
    /**
     * Constructeur pour initialiser un utilisateur avec seulement un nom d'utilisateur.
     *
     * @param username Le nom d'utilisateur unique.
     */
    public User(String username) {
        this.username = username;
    }

    /**
     * Constructeur pour initialiser un utilisateur avec un nom d'utilisateur et une liste de contrôles associés.
     *
     * @param username  Le nom d'utilisateur unique.
     * @param controles L'ensemble des contrôles associés à cet utilisateur (professeur).
     */
    public User(String username, Set<Controle> controles) {
        this.username = username;
        this.controles = controles;
    }

    /**
     * Récupère l'identifiant unique de l'utilisateur.
     *
     * @return L'identifiant de l'utilisateur.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Long getId() {
        return id;
    }

    /**
     * Définit l'identifiant unique de l'utilisateur.
     *
     * @param id L'identifiant de l'utilisateur.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Récupère le nom d'utilisateur.
     *
     * @return Le nom d'utilisateur de l'utilisateur.
     */
    @Column(name = "username", nullable = false, unique = true)
    public String getUsername() {
        return username;
    }

    /**
     * Définit le nom d'utilisateur.
     *
     * @param username Le nom d'utilisateur de l'utilisateur.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Récupère le mot de passe de l'utilisateur.
     *
     * @return Le mot de passe de l'utilisateur.
     */
    @Column(name = "password", nullable = false)
    public String getPassword() {
        return password;
    }

    /**
     * Définit le mot de passe de l'utilisateur.
     *
     * @param password Le mot de passe de l'utilisateur.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Récupère le statut activé de l'utilisateur.
     *
     * @return true si l'utilisateur est activé, sinon false.
     */
    @Column(name = "enabled", nullable = false)
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Définit le statut activé de l'utilisateur.
     *
     * @param enabled true si l'utilisateur est activé, sinon false.
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * Récupère la liste des contrôles associés au professeur.
     *
     * @return L'ensemble des contrôles associés au professeur.
     */
    @OneToMany(mappedBy = "professeur", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonManagedReference("professeur-controle")
    public Set<Controle> getControles() {
        return controles;
    }

    /**
     * Définit l'ensemble des contrôles associés au professeur.
     *
     * @param controles L'ensemble des contrôles à associer à cet utilisateur.
     */
    public void setControles(Set<Controle> controles) {
        this.controles = controles;
    }

    /**
     * Retourne une chaîne de caractères représentant l'objet `User` pour des fins de débogage ou d'affichage.
     *
     * @return La chaîne représentant l'utilisateur.
     */
    @Override
    public String toString() {
        return "User{id=" + id + ", username='" + username + "', enabled=" + enabled + "}";
    }
}
