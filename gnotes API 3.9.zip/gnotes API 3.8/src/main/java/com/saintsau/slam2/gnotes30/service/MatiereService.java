package com.saintsau.slam2.gnotes30.service;

import com.saintsau.slam2.gnotes30.entity.Matiere;
import com.saintsau.slam2.gnotes30.exeption.MatiereNotFoundException;
import com.saintsau.slam2.gnotes30.jpaRepository.MatiereRepository;

import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service qui gère les opérations liées aux matières.
 * Ce service permet de créer, lire, mettre à jour et supprimer des matières.
 */
@Service
public class MatiereService {

    private final MatiereRepository matiereRepository;

    /**
     * Constructeur du service `MatiereService`.
     * 
     * @param matiereRepository Le dépôt qui gère les entités `Matiere`.
     */
     MatiereService(MatiereRepository matiereRepository) {
    	super();
        this.matiereRepository = matiereRepository;
    }

    /**
     * Retourne le dépôt `MatiereRepository`.
     * 
     * @return Le dépôt `MatiereRepository`.
     */
    public MatiereRepository getMatiereRepository() {
        return matiereRepository;
    }
    
    /**
     * Récupère toutes les matières enregistrées dans la base de données.
     * 
     * @return Une liste de toutes les matières.
     */
    public List<Matiere> findAllMatiere() {
		return (List<Matiere>) matiereRepository.findAll(); 
	 }
    
    /**
     * Récupère une matière spécifique par son identifiant.
     * Si la matière n'existe pas, une exception `MatiereNotFoundException` est levée.
     * 
     * @param id L'identifiant de la matière à rechercher.
     * @return La matière correspondant à l'identifiant.
     * @throws MatiereNotFoundException Si la matière avec l'identifiant donné n'est pas trouvée.
     */
    public Matiere getMatiereById(Long id) {
       return matiereRepository.findById(id)
    		   .orElseThrow(() -> new MatiereNotFoundException(id));
    }

    /**
     * Crée une nouvelle matière et l'enregistre dans la base de données.
     * 
     * @param matiere La matière à créer.
     * @return La matière créée avec ses informations mises à jour (par exemple, son identifiant généré).
     */
    public Matiere saveMatiere(Matiere matiere) {
        return matiereRepository.save(matiere);
    }

    /**
     * Met à jour une matière existante dans la base de données.
     * Si la matière avec l'identifiant spécifié n'existe pas, une exception `MatiereNotFoundException` est levée.
     * 
     * @param id L'identifiant de la matière à mettre à jour.
     * @param updatedMatiere Les nouvelles informations de la matière.
     * @return La matière mise à jour.
     * @throws MatiereNotFoundException Si la matière avec l'identifiant donné n'est pas trouvée.
     */
    public Matiere updateMatiere(Long id, Matiere updatedMatiere) {
        Matiere matiere = matiereRepository.findById(id)
                .orElseThrow(() -> new MatiereNotFoundException(id));

        matiere.setIntitule(updatedMatiere.getIntitule());
        // Ajouter d'autres champs à mettre à jour si nécessaire
        return matiereRepository.save(matiere);
    }

    /**
     * Supprime une matière de la base de données par son identifiant.
     * Si la matière n'existe pas, une exception `MatiereNotFoundException` est levée.
     * 
     * @param id L'identifiant de la matière à supprimer.
     * @return La matière supprimée.
     * @throws MatiereNotFoundException Si la matière avec l'identifiant donné n'est pas trouvée.
     */
    public Matiere deleteMatiere(Long id) {
        Matiere matiere = matiereRepository.findById(id)
                .orElseThrow(() -> new MatiereNotFoundException(id));
        matiereRepository.delete(matiere);
        
        return matiere;
    }
}
