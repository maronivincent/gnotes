package com.saintsau.slam2.gnotes30.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.saintsau.slam2.gnotes30.entity.Controle;
import com.saintsau.slam2.gnotes30.service.ControlesService;

/**
 * Contrôleur REST pour la gestion des contrôles dans l'application.
 * Fournit des méthodes pour ajouter, récupérer, mettre à jour et supprimer des contrôles.
 * Utilise HATEOAS pour l'intégration de liens dans les réponses.
 */
@RestController
public class ControlesController {

    private final ControlesService controleService;

    /**
     * Constructeur du contrôleur qui injecte le service des contrôles.
     *
     * @param controleService Service de gestion des contrôles
     */
    ControlesController(ControlesService controleService) {
        this.controleService = controleService;
    }

    /**
     * Ajoute un nouveau contrôle pour un étudiant.
     * Cette méthode permet d'ajouter un contrôle à un étudiant en appelant le service approprié.
     * 
     * @param controle Le contrôle à ajouter
     * @return L'objet Controle ajouté, accompagné de liens HATEOAS pour l'accès à l'élément
     */
    @PostMapping("/controles")
    public EntityModel<Controle> newControle(@RequestBody Controle controle) {
        Controle savedControle = controleService.saveControle(controle);

        return EntityModel.of(savedControle,
                linkTo(methodOn(ControlesController.class).getControleById(savedControle.getId())).withSelfRel(),
                linkTo(methodOn(ControlesController.class).all()).withRel("controles"));
    }

    /**
     * Récupère la liste de tous les contrôles.
     * Cette méthode permet de récupérer tous les contrôles existants dans l'application.
     * 
     * @return Une collection de modèles représentant tous les contrôles, avec des liens HATEOAS pour chaque élément
     */
    @GetMapping("/controles")
    CollectionModel<EntityModel<Controle>> all() {
        List<EntityModel<Controle>> controles = StreamSupport.stream(controleService.getAllControles().spliterator(), false)
                .map((Controle controle) -> EntityModel.of(controle,
                        linkTo(methodOn(ControlesController.class).getControleById(controle.getId())).withSelfRel()))
                .collect(Collectors.toList());

        return CollectionModel.of(controles,
                linkTo(methodOn(ControlesController.class).all()).withSelfRel());
    }

    /**
     * Récupère un contrôle spécifique par son identifiant.
     * Cette méthode permet de récupérer un contrôle donné en fonction de son ID.
     * 
     * @param id L'ID du contrôle à récupérer
     * @return Un modèle représentant le contrôle trouvé, avec des liens HATEOAS pour l'accès et la mise à jour
     */
    @GetMapping("/controles/{id}")
    EntityModel<Controle> getControleById(@PathVariable Long id) {
        Controle controle = controleService.getContoleById(id);

        return EntityModel.of(controle,
                linkTo(methodOn(ControlesController.class).getControleById(id)).withSelfRel(),
                linkTo(methodOn(ControlesController.class).all()).withRel("controles"));
    }

    /**
     * Met à jour un contrôle existant.
     * Cette méthode permet de mettre à jour les informations d'un contrôle à partir de son identifiant.
     * 
     * @param id L'ID du contrôle à mettre à jour
     * @param updatedControle L'objet Controle contenant les nouvelles informations
     * @return L'objet Controle mis à jour, accompagné de liens HATEOAS
     */
    @PutMapping("/controles/{id}")
    public EntityModel<Controle> updateControle(@PathVariable Long id, @RequestBody Controle updatedControle) {
        Controle controle = controleService.updateControle(id, updatedControle);

        return EntityModel.of(controle,
                linkTo(methodOn(ControlesController.class).getControleById(controle.getId())).withSelfRel(),
                linkTo(methodOn(ControlesController.class).all()).withRel("controles"));
    }

    /**
     * Supprime un contrôle existant par son identifiant.
     * Cette méthode permet de supprimer un contrôle en fonction de son ID et retourne une réponse
     * avec des informations sur la suppression.
     * 
     * @param id L'ID du contrôle à supprimer
     * @return Un modèle contenant un message de confirmation et des liens HATEOAS
     */
    @DeleteMapping("/controles/{id}")
    EntityModel<Map<String, Object>> deleteControle(@PathVariable Long id) {
        Controle deletedControle = controleService.deleteControle(id);

        String message = "Controle supprimé: ";

        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        response.put("controle", deletedControle);

        return EntityModel.of(response,
                linkTo(methodOn(ControlesController.class).all()).withRel("controles"));
    }
}
