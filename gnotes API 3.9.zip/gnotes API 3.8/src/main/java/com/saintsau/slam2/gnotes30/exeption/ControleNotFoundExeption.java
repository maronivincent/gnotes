package com.saintsau.slam2.gnotes30.exeption;

/**
 * Exception personnalisée lancée lorsqu'un contrôle n'est pas trouvé dans la base de données.
 * Cette exception est une sous-classe de {@link RuntimeException} et permet de signaler l'absence 
 * d'un contrôle pour un identifiant donné.
 * 
 * Elle est principalement utilisée dans les services ou contrôleurs pour indiquer que l'on ne 
 * parvient pas à trouver un contrôle spécifique.
 */
public class ControleNotFoundExeption extends RuntimeException {

    /**
     * Constructeur de l'exception {@link ControleNotFoundExeption}.
     * 
     * @param id L'identifiant du contrôle qui n'a pas pu être trouvé.
     */
    public ControleNotFoundExeption(Long id) {
        // Appel au constructeur de RuntimeException avec un message décrivant l'erreur
        super("Could not find Controle with id: " + id);
    }
}
