package com.saintsau.slam2.gnotes30.jpaRepository;

import org.springframework.data.repository.CrudRepository;

import com.saintsau.slam2.gnotes30.entity.User;

/**
 * Interface de dépôt (repository) pour gérer les entités `User`.
 * Cette interface étend `CrudRepository` et permet d'effectuer des opérations CRUD sur les entités `User`.
 */
public interface UserRepository extends CrudRepository<User, Long> {

    /**
     * Recherche un `User` par son identifiant.
     * 
     * @param id L'identifiant de l'utilisateur à rechercher.
     * @return Un objet `User` correspondant à l'identifiant donné.
     * Si l'utilisateur n'est pas trouvé, il renvoie `null`.
     */
    User findById(long id);
}
