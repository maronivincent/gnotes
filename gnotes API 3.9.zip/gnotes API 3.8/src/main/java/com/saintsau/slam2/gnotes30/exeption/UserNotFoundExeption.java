package com.saintsau.slam2.gnotes30.exeption;

/**
 * Exception levée lorsqu'un utilisateur avec l'identifiant spécifié n'est pas trouvé.
 * Elle est utilisée pour signaler qu'un utilisateur avec un certain identifiant
 * n'existe pas dans la base de données ou n'a pas été trouvé dans l'application.
 */
public class UserNotFoundExeption extends RuntimeException {

    /**
     * Constructeur qui crée une nouvelle exception UserNotFoundExeption.
     * Le message d'exception inclut l'identifiant de l'utilisateur qui n'a pas été trouvé.
     *
     * @param id L'identifiant de l'utilisateur qui n'a pas été trouvé.
     */
    public UserNotFoundExeption(Long id) {
        super("Could not find User with id: " + id);
    }
}
