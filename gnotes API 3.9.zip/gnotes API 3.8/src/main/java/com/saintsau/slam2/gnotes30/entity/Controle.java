package com.saintsau.slam2.gnotes30.entity;

import jakarta.persistence.*;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Représente un contrôle effectué pour un étudiant dans une matière donnée.
 * Cette classe contient des informations sur le contrôle (note, coefficient, type, date) ainsi que des références
 * vers l'étudiant, le professeur et la matière correspondants.
 */
@Entity
@Table(name = "controles")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Controle {

    private Long id;              // Clé primaire
    private Etudiant etudiant;    // Référence à l'étudiant
    private User professeur;      // Référence au professeur (utilisateur)
    private Matiere matiere;      // Référence à la matière
    private int coefficient;      // Coefficient du contrôle
    private String type;          // Type de contrôle (DS, Oral, TP)
    private float note;           // Note obtenue
    private Date dateControle;    // Date du contrôle

    /**
     * Récupère l'identifiant du contrôle.
     * 
     * @return L'ID du contrôle.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Récupère l'étudiant associé à ce contrôle.
     * 
     * @return L'étudiant.
     */
    @ManyToOne
    @JoinColumn(name = "etudiant_id", nullable = false)
    @JsonBackReference(value = "etudiant-controle")
    public Etudiant getEtudiant() {
        return etudiant;
    }

    public void setEtudiant(Etudiant etudiant) {
        this.etudiant = etudiant;
    }

    /**
     * Récupère le professeur associé à ce contrôle.
     * 
     * @return Le professeur.
     */
    @ManyToOne
    @JoinColumn(name = "professeur_id", nullable = false)
    @JsonBackReference(value = "professeur-controle")  // Empêche la sérialisation pour éviter une référence circulaire
    public User getProfesseur() {
        return professeur;
    }

    public void setProfesseur(User professeur) {
        this.professeur = professeur;
    }

    /**
     * Récupère la matière du contrôle.
     * 
     * @return La matière.
     */
    @ManyToOne
    @JoinColumn(name = "matiere_id", nullable = false)
    @JsonBackReference(value = "matiere-controle")
    public Matiere getMatiere() {
        return matiere;
    }

    public void setMatiere(Matiere matiere) {
        this.matiere = matiere;
    }

    /**
     * Récupère le coefficient du contrôle.
     * 
     * @return Le coefficient.
     */
    @Column(name = "coefficient", nullable = false)
    public int getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(int coefficient) {
        this.coefficient = coefficient;
    }

    /**
     * Récupère le type du contrôle (par exemple, DS, Oral, TP).
     * 
     * @return Le type de contrôle.
     */
    @Column(name = "type", nullable = false)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    /**
     * Récupère la note obtenue lors du contrôle.
     * 
     * @return La note obtenue.
     */
    @Column(name = "note", nullable = false)
    public float getNote() {
        return note;
    }

    public void setNote(float note) {
        this.note = note;
    }

    /**
     * Récupère la date du contrôle.
     * 
     * @return La date du contrôle.
     */
    @Column(name = "date_controle", nullable = false)
    @Temporal(TemporalType.DATE)
    public Date getDateControle() {
        return dateControle;
    }

    public void setDateControle(Date dateControle) {
        this.dateControle = dateControle;
    }
}
