package com.saintsau.slam2.gnotes30.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.saintsau.slam2.gnotes30.entity.Etudiant;
import com.saintsau.slam2.gnotes30.service.EtudiantService;

/**
 * Contrôleur REST pour gérer les opérations liées aux étudiants.
 * Fournit des méthodes pour ajouter, récupérer, mettre à jour et supprimer des étudiants.
 * Utilise HATEOAS pour l'intégration des liens dans les réponses.
 */
@RestController
public class EtudiantController {

    private final EtudiantService etudiantService;

    /**
     * Constructeur de la classe {@link EtudiantController}.
     * 
     * @param etudiantService Le service utilisé pour gérer les étudiants
     */
    public EtudiantController(EtudiantService etudiantService) {
        this.etudiantService = etudiantService;
    }

    /**
     * Crée un nouvel étudiant dans la base de données.
     * 
     * @param etudiant L'objet Etudiant à ajouter
     * @return Un modèle contenant l'étudiant ajouté avec des liens HATEOAS
     */
    @PostMapping("/etudiants")
    public EntityModel<Etudiant> newEtudiant(@RequestBody Etudiant etudiant) {
        Etudiant savedEtudiant = etudiantService.saveEtudiant(etudiant);

        return EntityModel.of(savedEtudiant,
                linkTo(methodOn(EtudiantController.class).one(savedEtudiant.getNumero())).withSelfRel(),
                linkTo(methodOn(EtudiantController.class).all()).withRel("etudiants"));
    }

    /**
     * Récupère tous les étudiants dans la base de données.
     * 
     * @return Une collection d'étudiants sous forme de modèles avec des liens HATEOAS
     */
    @GetMapping("/etudiants")
    public CollectionModel<EntityModel<Etudiant>> all() {
        List<EntityModel<Etudiant>> etudiants = StreamSupport.stream(etudiantService.findAllEtudiant().spliterator(), false)
                .map((Etudiant etudiant) -> EntityModel.of(etudiant,
                        linkTo(methodOn(EtudiantController.class).one(etudiant.getNumero())).withSelfRel()))
                .collect(Collectors.toList());

        return CollectionModel.of(etudiants,
                linkTo(methodOn(EtudiantController.class).all()).withSelfRel());
    }

    /**
     * Récupère un étudiant spécifique en fonction de son identifiant.
     * 
     * @param id L'ID de l'étudiant à récupérer
     * @return Un modèle contenant l'étudiant trouvé avec des liens HATEOAS
     * @throws EtudiantNotFoundException Si l'étudiant n'est pas trouvé
     */
    @GetMapping("/etudiants/{id}")
    public EntityModel<Etudiant> one(@PathVariable Long id) {
        Etudiant etudiant = etudiantService.findEtudiantById(id);

        return EntityModel.of(etudiant,
                linkTo(methodOn(EtudiantController.class).one(id)).withSelfRel(),
                linkTo(methodOn(EtudiantController.class).all()).withRel("etudiants"));
    }

    /**
     * Met à jour les informations d'un étudiant existant.
     * 
     * @param id L'ID de l'étudiant à mettre à jour
     * @param updatedEtudiant L'objet Etudiant contenant les nouvelles informations
     * @return Un modèle contenant l'étudiant mis à jour avec des liens HATEOAS
     * @throws EtudiantNotFoundException Si l'étudiant n'est pas trouvé
     */
    @PutMapping("/etudiants/{id}")
    public EntityModel<Etudiant> updateEtudiant(@PathVariable Long id, @RequestBody Etudiant updatedEtudiant) {
        Etudiant etudiant = etudiantService.updateEtudiant(id, updatedEtudiant);

        return EntityModel.of(etudiant,
                linkTo(methodOn(EtudiantController.class).one(etudiant.getNumero())).withSelfRel(),
                linkTo(methodOn(EtudiantController.class).all()).withRel("etudiants"));
    }

    /**
     * Supprime un étudiant spécifique en fonction de son identifiant.
     * 
     * @param id L'ID de l'étudiant à supprimer
     * @return Un modèle contenant un message de confirmation et des liens HATEOAS
     * @throws EtudiantNotFoundException Si l'étudiant n'est pas trouvé
     */
    @DeleteMapping("/etudiants/{id}")
    public EntityModel<Map<String, Object>> deleteEtudiant(@PathVariable Long id) {
        Etudiant deletedEtudiant = etudiantService.deleteById(id);

        String message = "Etudiant supprimé: " + deletedEtudiant.getNom();

        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        response.put("etudiant", deletedEtudiant);

        return EntityModel.of(response,
                linkTo(methodOn(EtudiantController.class).all()).withRel("etudiants"));
    }
}
