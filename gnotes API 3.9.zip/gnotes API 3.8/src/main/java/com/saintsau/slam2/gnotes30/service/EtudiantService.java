package com.saintsau.slam2.gnotes30.service;

import java.util.List;
import org.springframework.stereotype.Service;

import com.saintsau.slam2.gnotes30.entity.Etudiant;
import com.saintsau.slam2.gnotes30.exeption.EtudiantNotFoundException;
import com.saintsau.slam2.gnotes30.jpaRepository.EtudiantRepository;

/**
 * Service qui gère les opérations liées aux étudiants.
 * Ce service permet de créer, lire, mettre à jour et supprimer des étudiants.
 */
@Service
public class EtudiantService {
	
	 private final EtudiantRepository etudiantRepository;

	 /**
	  * Constructeur du service `EtudiantService`.
	  * 
	  * @param etudiantRepository Le dépôt qui gère les entités `Etudiant`.
	  */
	 EtudiantService(EtudiantRepository etudiantRepository){
		 super();
		 this.etudiantRepository = etudiantRepository;
	 }
	 
	 /**
	  * Crée un nouvel étudiant et l'enregistre dans la base de données.
	  * 
	  * @param etudiant L'étudiant à créer.
	  * @return L'étudiant créé avec ses informations mises à jour (par exemple, son identifiant généré).
	  */
	 public Etudiant saveEtudiant(Etudiant etudiant) {
		return etudiantRepository.save(etudiant); 
	 }
	 
	 /**
	  * Récupère tous les étudiants présents dans la base de données.
	  * 
	  * @return Une liste contenant tous les étudiants.
	  */
	 public List<Etudiant> findAllEtudiant() {
		 return (List<Etudiant>) etudiantRepository.findAll(); 
	 }
	 
	 /**
	  * Récupère un étudiant spécifique par son identifiant.
	  * Si l'étudiant n'existe pas, une exception `EtudiantNotFoundException` est levée.
	  * 
	  * @param id L'identifiant de l'étudiant à rechercher.
	  * @return L'étudiant correspondant à l'identifiant.
	  * @throws EtudiantNotFoundException Si l'étudiant avec l'identifiant donné n'est pas trouvé.
	  */
	 public Etudiant findEtudiantById(Long id) {
		    return etudiantRepository.findById(id)
		            .orElseThrow(() -> new EtudiantNotFoundException(id));
		}

	 /**
	  * Supprime un étudiant de la base de données par son identifiant.
	  * Si l'étudiant n'existe pas, une exception `EtudiantNotFoundException` est levée.
	  * 
	  * @param id L'identifiant de l'étudiant à supprimer.
	  * @return L'étudiant supprimé.
	  * @throws EtudiantNotFoundException Si l'étudiant avec l'identifiant donné n'est pas trouvé.
	  */
     public Etudiant deleteById(Long id) {
    	    Etudiant etudiant = etudiantRepository.findById(id)
    	    		.orElseThrow(() -> new EtudiantNotFoundException(id));
    	    etudiantRepository.deleteById(id);
    	    return etudiant;
    	}
     
     /**
      * Met à jour un étudiant existant dans la base de données.
      * Si l'étudiant avec l'identifiant spécifié n'existe pas, une exception `EtudiantNotFoundException` est levée.
      * 
      * @param id L'identifiant de l'étudiant à mettre à jour.
      * @param updatedEtudiant Les nouvelles informations de l'étudiant.
      * @return L'étudiant mis à jour.
      * @throws EtudiantNotFoundException Si l'étudiant avec l'identifiant donné n'est pas trouvé.
      */
     public Etudiant updateEtudiant(Long id, Etudiant updatedEtudiant) {
         Etudiant etudiant = etudiantRepository.findById(id)
             .orElseThrow(() -> new EtudiantNotFoundException(id));
         
         // Mise à jour des champs nécessaires (par exemple, le nom, l'âge, etc.)
         etudiant.setNom(updatedEtudiant.getNom());
      
         return etudiantRepository.save(etudiant);
     }
}
