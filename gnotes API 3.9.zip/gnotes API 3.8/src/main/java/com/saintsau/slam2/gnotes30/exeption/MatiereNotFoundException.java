package com.saintsau.slam2.gnotes30.exeption;

/**
 * Exception levée lorsque la matière avec l'identifiant spécifié n'est pas trouvée.
 * Elle est utilisée pour signaler qu'une matière avec un certain identifiant
 * n'existe pas dans la base de données ou n'a pas été trouvée dans l'application.
 */
public class MatiereNotFoundException extends RuntimeException {

    /**
     * Constructeur qui crée une nouvelle exception MatiereNotFoundException.
     * Le message d'exception inclut l'identifiant de la matière qui n'a pas été trouvé.
     *
     * @param idMatiere L'identifiant de la matière qui n'a pas été trouvée.
     */
    public MatiereNotFoundException(Long idMatiere) {
        super("Could not find Matiere with id: " + idMatiere);
    }
}
