package com.saintsau.slam2.gnotes30.exeption;

/**
 * Exception personnalisée lancée lorsqu'un étudiant n'est pas trouvé dans la base de données.
 * Cette exception est une sous-classe de {@link RuntimeException} et permet de signaler l'absence 
 * d'un étudiant pour un identifiant donné.
 * 
 * Elle est principalement utilisée dans les services ou contrôleurs pour indiquer que l'on ne 
 * parvient pas à trouver un étudiant spécifique.
 */
public class EtudiantNotFoundException extends RuntimeException {

    /**
     * Constructeur de l'exception {@link EtudiantNotFoundException}.
     * 
     * @param id L'identifiant de l'étudiant qui n'a pas pu être trouvé.
     */
    public EtudiantNotFoundException(Long id) {
        // Appel au constructeur de RuntimeException avec un message décrivant l'erreur
        super("Could not find Etudiant with id: " + id);
    }
}
