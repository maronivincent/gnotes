package com.saintsau.slam2.gnotes30.service;

import com.saintsau.slam2.gnotes30.entity.User;
import com.saintsau.slam2.gnotes30.exeption.UserNotFoundExeption;
import com.saintsau.slam2.gnotes30.jpaRepository.UserRepository;

import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service qui gère les opérations liées aux utilisateurs.
 * Ce service permet de créer, lire, mettre à jour et supprimer des utilisateurs.
 */
@Service
public class UserService {

    private final UserRepository userRepository;

    /**
     * Retourne le dépôt `UserRepository` utilisé pour interagir avec la base de données des utilisateurs.
     * 
     * @return Le dépôt `UserRepository`.
     */
    public UserRepository getUserRepository() {
    	return userRepository;
    }
    
    /**
     * Constructeur du service `UserService`.
     * 
     * @param userRepository Le dépôt qui gère les entités `User`.
     */
    UserService(UserRepository userRepository) {
    	super();
    	this.userRepository = userRepository;
    }
    
    /**
     * Récupère tous les utilisateurs enregistrés dans la base de données.
     * 
     * @return Une liste de tous les utilisateurs.
     */
    public List<User> findAllUser() {
        return (List<User>) userRepository.findAll(); // Utilise CrudRepository, il peut être converti en List
    }
    
    /**
     * Récupère un utilisateur spécifique par son identifiant.
     * Si l'utilisateur n'existe pas, une exception `UserNotFoundExeption` est levée.
     * 
     * @param id L'identifiant de l'utilisateur à rechercher.
     * @return L'utilisateur correspondant à l'identifiant.
     * @throws UserNotFoundExeption Si l'utilisateur avec l'identifiant donné n'est pas trouvé.
     */
    public User getUserById(Long id) {
        return userRepository.findById(id)
        		.orElseThrow(() -> new UserNotFoundExeption(id));
    }

    /**
     * Crée un nouvel utilisateur et l'enregistre dans la base de données.
     * 
     * @param user L'utilisateur à créer.
     * @return L'utilisateur créé avec ses informations mises à jour (par exemple, son identifiant généré).
     */
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    /**
     * Met à jour un utilisateur existant dans la base de données.
     * Si l'utilisateur avec l'identifiant spécifié n'existe pas, une exception `UserNotFoundExeption` est levée.
     * 
     * @param id L'identifiant de l'utilisateur à mettre à jour.
     * @param updatedUser Les nouvelles informations de l'utilisateur.
     * @return L'utilisateur mis à jour.
     * @throws UserNotFoundExeption Si l'utilisateur avec l'identifiant donné n'est pas trouvé.
     */
    public User updateUser(Long id, User updatedUser) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new UserNotFoundExeption(id));
        user.setUsername(updatedUser.getUsername());
        user.setPassword(updatedUser.getPassword());
        user.setEnabled(updatedUser.isEnabled());
        return userRepository.save(user);
    }

    /**
     * Supprime un utilisateur de la base de données par son identifiant.
     * Si l'utilisateur n'existe pas, une exception `UserNotFoundExeption` est levée.
     * 
     * @param id L'identifiant de l'utilisateur à supprimer.
     * @return L'utilisateur supprimé.
     * @throws UserNotFoundExeption Si l'utilisateur avec l'identifiant donné n'est pas trouvé.
     */
    public User deleteUser(Long id) {
        User user = userRepository.findById(id)
            .orElseThrow(() -> new UserNotFoundExeption(id));
       
        userRepository.deleteById(id);
        return user;
    }
}
