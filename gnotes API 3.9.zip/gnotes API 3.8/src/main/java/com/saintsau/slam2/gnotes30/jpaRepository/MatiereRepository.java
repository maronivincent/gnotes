package com.saintsau.slam2.gnotes30.jpaRepository;

import org.springframework.data.repository.CrudRepository;

import com.saintsau.slam2.gnotes30.entity.Matiere;

/**
 * Interface de dépôt (repository) pour gérer les entités `Matiere`.
 * Cette interface étend `CrudRepository` et permet d'effectuer des opérations CRUD sur les entités `Matiere`.
 */
public interface MatiereRepository extends CrudRepository<Matiere, Long> {

    /**
     * Recherche une `Matiere` par son identifiant.
     * 
     * @param id L'identifiant de la matière à rechercher.
     * @return Un objet `Matiere` correspondant à l'identifiant donné.
     * Si la matière n'est pas trouvée, il renvoie `null`.
     */
    Matiere findById(long id);
}
