package com.saintsau.slam2.gnotes30.entity;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;

/**
 * Représente une matière dans le système. Cette classe contient des informations
 * telles que l'intitulé de la matière ainsi que les contrôles associés à cette matière.
 * Elle est mappée à la table `matieres` dans la base de données.
 */
@Entity
@Table(name = "matieres")
public class Matiere {

    /**
     * Clé primaire unique de la matière.
     */
    private Long id;

    /**
     * Intitulé de la matière (par exemple, "Mathématiques", "Physique", etc.).
     */
    private String intitule;

    /**
     * Ensemble des contrôles associés à cette matière.
     */
    private Set<Controle> controles;

    /**
     * Constructeur pour initialiser une matière avec un intitulé.
     *
     * @param intitule Le nom ou intitulé de la matière (ex : Mathématiques).
     */
    public Matiere(String intitule) {
        this.intitule = intitule;
    }

    /**
     * Constructeur par défaut pour créer une matière sans initialisation.
     */
    public Matiere() {
    }

    /**
     * Récupère l'identifiant unique de la matière.
     *
     * @return L'identifiant de la matière.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Long getId() {
        return id;
    }

    /**
     * Définit l'identifiant unique de la matière.
     *
     * @param id L'identifiant à définir pour la matière.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Récupère l'intitulé de la matière.
     *
     * @return L'intitulé de la matière.
     */
    @Column(name = "intitule")
    public String getIntitule() {
        return intitule;
    }

    /**
     * Définit l'intitulé de la matière.
     *
     * @param intitule L'intitulé de la matière à définir.
     */
    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }

    /**
     * Récupère l'ensemble des contrôles associés à cette matière.
     *
     * @return L'ensemble des contrôles liés à la matière.
     */
    @OneToMany(mappedBy = "matiere", cascade = CascadeType.ALL)
    @JsonManagedReference("matiere-controle")
    //@JoinColumn(name = "controle_id") // Clé étrangère vers l'entité Controle
    public Set<Controle> getControle() {
        return controles;
    }

    /**
     * Définit l'ensemble des contrôles associés à cette matière.
     *
     * @param controle L'ensemble des contrôles à associer à la matière.
     */
    public void setControle(Set<Controle> controle) {
        this.controles = controle;
    }
}
