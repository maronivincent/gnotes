package com.saintsau.slam2.gnotes30.controller;

import com.saintsau.slam2.gnotes30.entity.User;
import com.saintsau.slam2.gnotes30.service.UserService;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

/**
 * Contrôleur REST pour gérer les utilisateurs.
 * Ce contrôleur permet de créer, récupérer, mettre à jour et supprimer des utilisateurs.
 * Il utilise HATEOAS pour intégrer des liens dans les réponses.
 */
@RestController
public class UserController {
    private final UserService userService;

    /**
     * Constructeur pour initialiser le contrôleur avec le service utilisateur.
     *
     * @param userService Le service utilisateur utilisé pour effectuer les opérations sur les utilisateurs
     */
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Crée un nouvel utilisateur dans le système.
     * 
     * @param user L'utilisateur à créer
     * @return Un modèle contenant l'utilisateur créé avec des liens HATEOAS
     */
    @PostMapping("/users")
    public EntityModel<User> newUser(@RequestBody User user) {
        // Sauvegarde de l'utilisateur via le service
        User savedUser = userService.saveUser(user);

        // Retourne un modèle contenant l'utilisateur avec des liens HATEOAS
        return EntityModel.of(savedUser,
                linkTo(methodOn(UserController.class).getUserById(savedUser.getId())).withSelfRel(),
                linkTo(methodOn(UserController.class).all()).withRel("users"));
    }

    /**
     * Récupère tous les utilisateurs du système.
     * 
     * @return Une collection d'entités contenant les utilisateurs avec des liens HATEOAS
     */
    @GetMapping("/users")
    public CollectionModel<EntityModel<User>> all() {
        // Récupère tous les utilisateurs via le service et les transforme en modèles avec des liens HATEOAS
        List<EntityModel<User>> users = StreamSupport.stream(userService.findAllUser().spliterator(), false)
                .map((User user) -> EntityModel.of(user,
                        linkTo(methodOn(UserController.class).getUserById(user.getId())).withSelfRel()))
                .collect(Collectors.toList());

        // Retourne la collection d'utilisateurs avec un lien HATEOAS vers soi-même
        return CollectionModel.of(users,
                linkTo(methodOn(UserController.class).all()).withSelfRel());
    }

    /**
     * Récupère un utilisateur spécifique par son ID.
     * 
     * @param id L'ID de l'utilisateur à récupérer
     * @return Un modèle contenant l'utilisateur demandé avec des liens HATEOAS
     */
    @GetMapping("/users/{id}")
    public EntityModel<User> getUserById(@PathVariable Long id) {
        // Récupère l'utilisateur via le service
        User user = userService.getUserById(id);

        // Retourne l'utilisateur avec des liens HATEOAS
        return EntityModel.of(user,
                linkTo(methodOn(UserController.class).getUserById(id)).withSelfRel(),
                linkTo(methodOn(UserController.class).all()).withRel("users"));
    }

    /**
     * Met à jour un utilisateur existant.
     * 
     * @param id L'ID de l'utilisateur à mettre à jour
     * @param updatedUser Un objet utilisateur contenant les nouvelles données
     * @return Un modèle contenant l'utilisateur mis à jour avec des liens HATEOAS
     */
    @PutMapping("/users/{id}")
    public EntityModel<User> updateUser(@PathVariable Long id, @RequestBody User updatedUser) {
        // Met à jour l'utilisateur via le service
        User user = userService.updateUser(id, updatedUser);

        // Retourne l'utilisateur mis à jour avec des liens HATEOAS
        return EntityModel.of(user,
                linkTo(methodOn(UserController.class).getUserById(user.getId())).withSelfRel(),
                linkTo(methodOn(UserController.class).all()).withRel("users"));
    }

    /**
     * Supprime un utilisateur du système par son ID.
     * 
     * @param id L'ID de l'utilisateur à supprimer
     * @return Un modèle contenant un message de confirmation et l'utilisateur supprimé avec des liens HATEOAS
     */
    @DeleteMapping("/users/{id}")
    public EntityModel<Map<String, Object>> deleteUser(@PathVariable Long id) {
        // Supprime l'utilisateur via le service
        User deletedUser = userService.deleteUser(id);

        // Message de confirmation
        String message = "Utilisateur supprimé: " + deletedUser.getUsername();

        // Crée une réponse avec le message et l'utilisateur supprimé
        Map<String, Object> response = new HashMap<>();
        response.put("message", message);
        response.put("user", deletedUser);

        // Retourne le message et l'utilisateur supprimé avec des liens HATEOAS
        return EntityModel.of(response,
                linkTo(methodOn(UserController.class).all()).withRel("users"));
    }
}
