package com.saintsau.slam2.gnotes30.jpaRepository;

import org.springframework.data.repository.CrudRepository;

import com.saintsau.slam2.gnotes30.entity.Etudiant;

/**
 * Interface de dépôt (repository) pour gérer les entités `Etudiant`.
 * Cette interface étend `CrudRepository` et permet d'effectuer des opérations CRUD sur les entités `Etudiant`.
 */
public interface EtudiantRepository extends CrudRepository<Etudiant, Long> {

    /**
     * Recherche un `Etudiant` par son identifiant.
     * 
     * @param Id L'identifiant de l'étudiant à rechercher.
     * @return Un objet `Etudiant` correspondant à l'identifiant donné.
     * Si l'entité n'est pas trouvée, il renvoie `null`.
     */
    Etudiant findById(long Id);
}
