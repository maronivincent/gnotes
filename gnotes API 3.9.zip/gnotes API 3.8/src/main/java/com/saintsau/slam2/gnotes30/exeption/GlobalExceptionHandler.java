package com.saintsau.slam2.gnotes30.exeption;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

/**
 * Classe de gestion des exceptions globales pour l'application.
 * Cette classe utilise {@link RestControllerAdvice} pour intercepter et traiter les exceptions 
 * lancées au niveau des contrôleurs.
 * 
 * Elle permet de centraliser la gestion des erreurs, en renvoyant des réponses structurées 
 * et appropriées pour les exceptions spécifiques comme les erreurs de non-trouvabilité des entités
 * ou des erreurs générales.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Méthode pour gérer l'exception {@link EtudiantNotFoundException}.
     * Lorsque cette exception est lancée, la réponse renvoyée est un code HTTP 404 (Not Found)
     * accompagné d'un message d'erreur spécifiant l'ID de l'étudiant non trouvé.
     *
     * @param ex L'exception de type {@link EtudiantNotFoundException} à traiter.
     * @return Un map contenant le message d'erreur.
     */
    @ExceptionHandler(EtudiantNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Map<String, String> handleEtudiantNotFoundException(EtudiantNotFoundException ex) {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("error", ex.getMessage());  // Message d'erreur spécifique à l'exception
        return errorMap;
    }

    /**
     * Méthode pour gérer l'exception {@link MatiereNotFoundException}.
     * Lorsque cette exception est lancée, la réponse renvoyée est un code HTTP 404 (Not Found)
     * accompagné d'un message d'erreur spécifiant la matière non trouvée.
     *
     * @param ex L'exception de type {@link MatiereNotFoundException} à traiter.
     * @return Un map contenant le message d'erreur.
     */
    @ExceptionHandler(MatiereNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public Map<String, String> handleMatiereNotFoundException(MatiereNotFoundException ex) {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("error", ex.getMessage());  // Message d'erreur spécifique à l'exception
        return errorMap;
    }

    /**
     * Méthode pour gérer toutes les autres exceptions générales.
     * Lorsque des exceptions non spécifiques sont lancées, cette méthode renvoie une réponse
     * avec un code HTTP 500 (Internal Server Error) et un message d'erreur générique.
     *
     * @param ex L'exception générale à traiter.
     * @return Un map contenant un message d'erreur générique.
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Map<String, String> handleGeneralException(Exception ex) {
        Map<String, String> errorMap = new HashMap<>();
        errorMap.put("error", "An unexpected error occurred: " + ex.getMessage());  // Message d'erreur générique
        return errorMap;
    }
}
