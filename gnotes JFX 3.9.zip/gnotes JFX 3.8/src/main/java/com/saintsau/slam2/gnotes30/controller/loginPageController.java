package com.saintsau.slam2.gnotes30.controller;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.saintsau.slam2.gnotes30.entity.User;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Screen;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Scanner;

/**
 * Contrôleur de la page de connexion de l'application.
 * Gère les interactions de l'utilisateur sur la page de connexion,
 * l'authentification via l'API (http://localhost:8080/users)
 * et la redirection vers la page d'accueil en cas de succès.
 */
public class loginPageController {

    @FXML
    private TextField usernameField;  // Champ pour saisir le nom d'utilisateur

    @FXML
    private PasswordField passwordField;  // Champ pour saisir le mot de passe

    @FXML
    private Label errorLabel;  // Label pour afficher les erreurs de connexion

    @FXML
    private Button loginButton;  // Bouton pour se connecter

    private static final String API_URL = "http://localhost:8080/users";  // URL de l'API pour récupérer les utilisateurs

    /**
     * Méthode qui est appelée lorsqu'un utilisateur clique sur le bouton de connexion.
     * Cette méthode tente d'authentifier l'utilisateur en utilisant le nom d'utilisateur et le mot de passe.
     * Si l'authentification réussit, elle charge la page d'accueil. Sinon, un message d'erreur est affiché.
     */
    @FXML
    private void GoToHome() {
        String username = usernameField.getText();  // Récupère le nom d'utilisateur saisi
        String password = passwordField.getText();  // Récupère le mot de passe saisi

        if (authenticateUser(username, password)) {
            try {
                // Charge la page d'accueil si l'authentification est réussie
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/openjfx/sio2E4/homePage.fxml"));
                Parent root = loader.load();

                Stage stage = (Stage) loginButton.getScene().getWindow();  // Obtient la fenêtre actuelle

                // Obtient les dimensions de l'écran pour maximiser la fenêtre
                Screen screen = Screen.getPrimary();
                Rectangle2D bounds = screen.getVisualBounds();

                Scene scene = new Scene(root, bounds.getWidth(), bounds.getHeight());
                stage.setScene(scene);  // Définir la nouvelle scène
                stage.show();  // Affiche la scène

            } catch (IOException e) {
                e.printStackTrace();  // Affiche l'erreur si la page d'accueil ne peut pas être chargée
            }
        } else {
            // Affiche un message d'erreur si l'authentification échoue
            errorLabel.setText("Identifiant ou mot de passe incorrect !");
            errorLabel.setStyle("-fx-text-fill: red;");
        }
    }

    /**
     * Méthode qui authentifie l'utilisateur en vérifiant son nom d'utilisateur et mot de passe
     * via une connexion HTTP à l'API.
     * 
     * @param username Le nom d'utilisateur saisi
     * @param password Le mot de passe saisi
     * @return true si l'authentification est réussie, sinon false
     */
    private boolean authenticateUser(String username, String password) {
        try {
            // Connexion à l'API pour récupérer les utilisateurs
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() != 200) {
                errorLabel.setText("Erreur lors de la connexion à l'API.");
                errorLabel.setStyle("-fx-text-fill: red;");
                return false;
            }

            // Récupère la réponse JSON de l'API
            StringBuilder jsonStr = new StringBuilder();
            try (Scanner scanner = new Scanner(conn.getInputStream())) {
                while (scanner.hasNext()) {
                    jsonStr.append(scanner.nextLine());
                }
            }

            // Mappe la réponse JSON en une liste d'utilisateurs
            ObjectMapper mapper = new ObjectMapper();
            ApiResponse<User> response = mapper.readValue(
                jsonStr.toString(),
                mapper.getTypeFactory().constructParametricType(ApiResponse.class, User.class)
            );

            List<User> users = response.getEmbedded() != null ? response.getEmbedded().getItems() : null;

            if (users != null) {
                for (User user : users) {
                    String dbPassword = user.getPassword();
                    if (dbPassword != null && dbPassword.startsWith("{noop}")) {
                        dbPassword = dbPassword.substring(6);  // Retire le préfixe {noop} pour les mots de passe non cryptés
                    }

                    if (user.getUsername().equals(username) && dbPassword.equals(password)) {
                        return true;  // L'authentification est réussie si le nom d'utilisateur et le mot de passe correspondent
                    }
                }
            }

            return false;  // Retourne false si l'utilisateur n'a pas été trouvé ou si les mots de passe ne correspondent pas

        } catch (IOException e) {
            e.printStackTrace();
            errorLabel.setText("Erreur de connexion à l'API.");
            errorLabel.setStyle("-fx-text-fill: red;");
            return false;  // Retourne false si une erreur survient lors de la communication avec l'API
        }
    }

    /**
     * Classe générique pour la réponse de l'API contenant des utilisateurs.
     * Cette classe permet de désérialiser la réponse JSON de l'API.
     * 
     * @param <T> Le type de l'élément contenu dans la réponse (ici, des utilisateurs)
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ApiResponse<T> {

        @JsonProperty("_embedded")
        private Embedded<T> embedded;

        public Embedded<T> getEmbedded() {
            return embedded;
        }

        public void setEmbedded(Embedded<T> embedded) {
            this.embedded = embedded;
        }

        /**
         * Classe interne représentant les éléments contenus dans la réponse de l'API (la liste des utilisateurs).
         * 
         * @param <T> Le type des éléments (ici, des utilisateurs)
         */
        @JsonIgnoreProperties(ignoreUnknown = true)
        public static class Embedded<T> {
            @JsonProperty("userList")
            private List<T> users;

            public List<T> getItems() {
                return users;
            }

            public void setUsers(List<T> users) {
                this.users = users;
            }
        }
    }
}
