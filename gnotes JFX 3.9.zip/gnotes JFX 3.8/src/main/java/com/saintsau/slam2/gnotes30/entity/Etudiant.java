package com.saintsau.slam2.gnotes30.entity;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;

/**
 * Entité représentant un étudiant dans l'application.
 * Un étudiant possède un numéro unique, un nom, un prénom,
 * et une liste de contrôles associés.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name = "etudiants")
public class Etudiant {

    private String nom;                        // Nom de l'étudiant
    private String prenom;                     // Prénom de l'étudiant
    private Long numero;                       // Numéro unique de l'étudiant (clé primaire)
    private Set<Controle> controles;           // Ensemble des contrôles associés à l'étudiant

    /**
     * Constructeur avec nom, prénom, numéro et contrôles.
     * @param nom Nom de l'étudiant
     * @param prenom Prénom de l'étudiant
     * @param numero Numéro unique
     * @param controles Contrôles liés à l'étudiant
     */
    public Etudiant(String nom, String prenom, Long numero, Set<Controle> controles) {
        this.nom = nom;
        this.prenom = prenom;
        this.numero = numero;
        this.controles = controles;
    }

    /**
     * Constructeur avec nom, prénom et contrôles (sans numéro).
     * @param nom Nom de l'étudiant
     * @param prenom Prénom de l'étudiant
     * @param controles Contrôles liés à l'étudiant
     */
    public Etudiant(String nom, String prenom, Set<Controle> controles) {
        this.nom = nom;
        this.prenom = prenom;
        this.controles = controles;
    }

    /**
     * Constructeur avec nom et prénom uniquement.
     * @param nom Nom de l'étudiant
     * @param prenom Prénom de l'étudiant
     */
    public Etudiant(String nom, String prenom) {
        this.nom = nom;
        this.prenom = prenom;
    }

    /** Constructeur vide requis par JPA. */
    public Etudiant() {
    }

    /**
     * Retourne le nom de l'étudiant.
     * @return nom
     */
    @Column(name = "nom")
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Retourne le prénom de l'étudiant.
     * @return prénom
     */
    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    /**
     * Retourne le numéro unique de l'étudiant.
     * @return numéro
     */
    @Id
    @Column(name = "numero")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getNumero() {
        return numero;
    }

    public void setNumero(Long numero) {
        this.numero = numero;
    }

    /**
     * Retourne les contrôles associés à cet étudiant.
     * @return ensemble de contrôles
     */
    @OneToMany(mappedBy = "etudiant", cascade = CascadeType.ALL)
    @JsonManagedReference("etudiant-controle")
    public Set<Controle> getControles() {
        return controles;
    }

    public void setControles(Set<Controle> controles) {
        this.controles = controles;
    }
}
