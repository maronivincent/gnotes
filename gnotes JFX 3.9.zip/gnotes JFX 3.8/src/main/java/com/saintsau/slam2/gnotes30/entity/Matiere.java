package com.saintsau.slam2.gnotes30.entity;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;

/**
 * Entité représentant une matière dans l'application.
 * Une matière possède un identifiant unique et un intitulé,
 * ainsi qu'une collection de contrôles associés.
 */
@Entity
@Table(name = "matieres")
public class Matiere {

    private Long id;            // Clé primaire
    private String intitule;    // Intitulé de la matière
    private Set<Controle> controles;  // Ensemble des contrôles associés à la matière

    /**
     * Constructeur avec intitulé de la matière.
     * @param intitule Intitulé de la matière
     */
    public Matiere(String intitule) {
        this.intitule = intitule;
    }

    /** Constructeur vide requis par JPA. */
    public Matiere() {
    }

    /**
     * Retourne l'identifiant unique de la matière.
     * @return id Identifiant de la matière
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Retourne l'intitulé de la matière.
     * @return intitule Intitulé de la matière
     */
    @Column(name = "intitule")
    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }

    /**
     * Retourne les contrôles associés à cette matière.
     * @return ensemble de contrôles
     */
    @OneToMany(mappedBy = "matiere", cascade = CascadeType.ALL)
    @JsonManagedReference("matiere-controle")
    public Set<Controle> getControle() {
        return controles;
    }

    public void setControle(Set<Controle> controle) {
        this.controles = controle;
    }

}
