package com.saintsau.slam2.gnotes30.controller;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

/**
 * Contrôleur pour ajouter un étudiant dans l'application.
 * Cette classe gère l'interface utilisateur permettant de saisir les informations d'un étudiant,
 * telles que son nom.
 */
public class AddStudentController {

    @FXML
    private TextField nameField;  // Champ pour saisir le nom de l'étudiant

    /**
     * Méthode appelée lorsque l'utilisateur clique pour enregistrer un étudiant.
     * Elle récupère le nom de l'étudiant saisi dans le champ de texte,
     * effectue une vérification pour s'assurer que le champ n'est pas vide,
     * et imprime les informations de l'étudiant dans la console.
     * Si le champ est rempli, l'étudiant est ajouté et le champ est réinitialisé.
     */
    @FXML
    private void saveStudent() {
        // Récupère le nom de l'étudiant saisi
        String name = nameField.getText();

        // Vérifie si le champ est rempli
        if (name.isEmpty()) {
            System.out.println("Tous les champs doivent être remplis !");
            return; // Arrête la méthode si le champ est vide
        }

        // Affiche les informations de l'étudiant ajouté (en pratique, cela pourrait être sauvegardé dans une base de données)
        System.out.println("Élève ajouté : " + name);

        // Optionnellement, réinitialise le champ après l'ajout de l'étudiant
        nameField.clear();
    }
}
