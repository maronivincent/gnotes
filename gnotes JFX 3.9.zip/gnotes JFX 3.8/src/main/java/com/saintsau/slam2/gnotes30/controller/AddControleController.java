package com.saintsau.slam2.gnotes30.controller;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

/**
 * Contrôleur pour ajouter un contrôle dans l'application.
 * Cette classe gère l'interface utilisateur pour saisir les informations d'un contrôle,
 * telles que le nom de la matière, le type, le coefficient, la note et le nom de l'étudiant.
 */
public class AddControleController {

    @FXML
    private TextField intituleField; // Champ pour saisir le nom de la matière

    @FXML
    private TextField typeField; // Champ pour saisir le type de contrôle (ex. : examen, devoir, etc.)

    @FXML
    private TextField coefField; // Champ pour saisir le coefficient du contrôle

    @FXML
    private TextField noteField; // Champ pour saisir la note du contrôle

    @FXML
    private TextField nameStudentField; // Champ pour saisir le nom de l'étudiant

    /**
     * Méthode appelée lorsque l'utilisateur clique pour enregistrer un contrôle.
     * Elle récupère les informations saisies par l'utilisateur dans les champs du formulaire,
     * effectue une vérification pour s'assurer que tous les champs sont remplis,
     * et imprime les informations du contrôle dans la console.
     * Si tous les champs sont remplis, le contrôle est ajouté et les champs sont réinitialisés.
     */
    @FXML
    private void saveControle() {
        // Récupère les valeurs des champs de saisie
        String matiere = intituleField.getText();
        String type = typeField.getText();
        String coef = coefField.getText();
        String note = noteField.getText();
        String studentName = nameStudentField.getText();

        // Vérifie si tous les champs sont remplis
        if (matiere.isEmpty() || type.isEmpty() || coef.isEmpty() || note.isEmpty() || studentName.isEmpty())  {
            System.out.println("Tous les champs doivent être remplis !");
            return; // Arrête la méthode si un champ est vide
        }

        // Affiche les informations du contrôle ajouté (en pratique, cela pourrait être sauvegardé dans une base de données)
        System.out.println("Controle ajouté : " + matiere + ", Type : " + type + " , Coefficient : " + coef + " , Note : " + note + " , Eleve : " + studentName);

        // Optionnellement, réinitialise les champs après l'ajout du contrôle
        intituleField.clear();
        typeField.clear();
        coefField.clear();
        noteField.clear();
        nameStudentField.clear();
    }
}
