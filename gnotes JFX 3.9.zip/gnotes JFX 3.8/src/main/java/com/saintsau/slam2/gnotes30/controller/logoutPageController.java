package com.saintsau.slam2.gnotes30.controller;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.saintsau.slam2.gnotes30.entity.Etudiant;
import com.saintsau.slam2.gnotes30.entity.User;
import com.saintsau.slam2.gnotes30.entity.Controle;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Scanner;

/**
 * Contrôleur de la page principale après la connexion (logoutPageController).
 * Gère l'affichage et le chargement des données des étudiants, professeurs et contrôles.
 */
public class logoutPageController {
    
    @FXML
    private Button actiontarget;
    
    @FXML
    private TableView<Etudiant> studentTable;
    @FXML
    private TableColumn<Etudiant, String> columnNomStudent;
    @FXML
    private TableColumn<Etudiant, String> columnPrenomStudent;
    
    @FXML
    private TableView<User> professorTable;
    @FXML
    private TableColumn<User, String> columnNomProfessor;
    
    @FXML
    private TableView<Controle> controleTable;
    @FXML
    private TableColumn<Controle, String> columnMatiereControle;
    @FXML
    private TableColumn<Controle, String> columnCoefControle;
    @FXML
    private TableColumn<Controle, String> columnTypeControle;
    @FXML
    private TableColumn<Controle, String> columnNoteControle;
    @FXML
    private TableColumn<Controle, String> columnNomEtudiantControle;
    @FXML
    private TableColumn<Controle, String> columnDateControle;
    
    private final String API_BASE_URL = "http://localhost:8080";
    
    /**
     * Méthode d'initialisation appelée automatiquement par JavaFX.
     * Configure les colonnes des tables et charge les données depuis l'API.
     */
    @FXML
    public void initialize() {
        setupTables();
        loadStudentsFromAPI();
        loadProfsFromAPI();
        loadControlesFromAPI();
    }
    
    /**
     * Configure les colonnes des tables avec les propriétés des entités affichées.
     */
    private void setupTables() {
        columnNomStudent.setCellValueFactory(new PropertyValueFactory<>("nom"));
        columnPrenomStudent.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        
        columnNomProfessor.setCellValueFactory(new PropertyValueFactory<>("username"));
        
        columnMatiereControle.setCellValueFactory(new PropertyValueFactory<>("intituleMatiere"));
        columnCoefControle.setCellValueFactory(new PropertyValueFactory<>("coefficient"));
        columnTypeControle.setCellValueFactory(new PropertyValueFactory<>("type"));
        columnNoteControle.setCellValueFactory(new PropertyValueFactory<>("note"));
        columnNomEtudiantControle.setCellValueFactory(new PropertyValueFactory<>("nomEtudiant"));
        columnDateControle.setCellValueFactory(new PropertyValueFactory<>("dateControle"));
    }
    
    /**
     * Charge les données des étudiants depuis l'API et les affiche dans la table correspondante.
     * Chemin vers l'api : http://localhost:8080/etudiants
     */
    private void loadStudentsFromAPI() {
        fetchData(API_BASE_URL + "/etudiants", studentTable, Etudiant.class);
    }

    /**
     * Charge les données des professeurs depuis l'API et les affiche dans la table correspondante.
     * chemin vers l'api : http://localhost:8080/users
     */
    private void loadProfsFromAPI() {
        fetchData(API_BASE_URL + "/users", professorTable, User.class);
    }

    /**
     * Charge les données des contrôles depuis l'API et les affiche dans la table correspondante.
     * chemin vers l'api : http://localhost:8080/controles
     */
    private void loadControlesFromAPI() {
        fetchData(API_BASE_URL + "/controles", controleTable, Controle.class);
    }

    /**
     * Classe représentant une réponse générique de l'API contenant une liste d'objets embarqués.
     * @param <T> Le type d'objet contenu dans la réponse (Etudiant, User, ou Controle).
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ApiResponse<T> {
        @JsonProperty("_embedded")
        private Embedded<T> embedded;

        /**
         * Retourne l'objet Embedded contenant les listes d'entités.
         * @return L'objet Embedded contenant les données.
         */
        public Embedded<T> getEmbedded() {
            return embedded;
        }

        /**
         * Définit l'objet Embedded contenant les listes d'entités.
         * @param embedded L'objet Embedded à définir.
         */
        public void setEmbedded(Embedded<T> embedded) {
            this.embedded = embedded;
        }

        /**
         * Classe interne représentant la section "_embedded" d'une réponse HAL.
         */
        public static class Embedded<T> {
            @JsonProperty("etudiantList")
            private List<T> etudiants;

            @JsonProperty("userList")
            private List<T> users;

            @JsonProperty("controleList")
            private List<T> controles;

            /**
             * Retourne la liste d'objets (étudiants, utilisateurs ou contrôles) selon la réponse.
             * @return Liste d'objets T.
             */
            public List<T> getItems() {
                if (etudiants != null) return etudiants;
                if (users != null) return users;
                if (controles != null) return controles;
                return null;
            }
        }
    }

    /**
     * Récupère les données depuis l'API spécifiée, les désérialise et les insère dans la table donnée.
     * @param urlString L'URL de l'API à interroger.
     * @param tableView La table JavaFX dans laquelle insérer les données.
     * @param clazz Le type d'objet attendu dans la réponse.
     */
    private <T> void fetchData(String urlString, TableView<T> tableView, Class<T> clazz) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() != 200) {
                System.out.println("HTTP Error: " + conn.getResponseCode());
                return;
            }

            StringBuilder jsonStr = new StringBuilder();
            try (Scanner scanner = new Scanner(conn.getInputStream())) {
                while (scanner.hasNext()) {
                    jsonStr.append(scanner.nextLine());
                }
            }

            // Print API response for debugging
            System.out.println("Response from " + urlString + ": " + jsonStr.toString());

            ObjectMapper mapper = new ObjectMapper();
            ApiResponse<T> response = mapper.readValue(jsonStr.toString(),
                mapper.getTypeFactory().constructParametricType(ApiResponse.class, clazz));

            if (response.getEmbedded() != null && response.getEmbedded().getItems() != null) {
                tableView.setItems(FXCollections.observableArrayList(response.getEmbedded().getItems()));
            } else {
                System.out.println("No data found for: " + urlString);
            }
        } catch (Exception e) {
            System.err.println("Error fetching data from API: " + urlString);
            e.printStackTrace();
        }
    }

    /**
     * Redirige l'utilisateur vers la page de connexion.
     */
    @FXML
    private void GoToLog() {
        navigateTo("/org/openjfx/sio2E4/loginPage.fxml");
    }

    /**
     * Ouvre une nouvelle fenêtre pour ajouter un professeur.
     */
    @FXML
    private void goToAddProfessorScreen() {
        openWindow("/org/openjfx/sio2E4/addProf.fxml", "Ajouter un Professeur");
    }

    /**
     * Ouvre une nouvelle fenêtre pour ajouter un étudiant.
     */
    @FXML
    private void goToAddStudentScreen() {
        openWindow("/org/openjfx/sio2E4/addStudent.fxml", "Ajouter un Eleve");
    }

    /**
     * Ouvre une nouvelle fenêtre pour ajouter un contrôle.
     */
    @FXML
    private void goToAddControleScreen() {
        openWindow("/org/openjfx/sio2E4/addControle.fxml", "Ajouter un Controle");
    }

    /**
     * Change la scène actuelle pour une autre page FXML donnée.
     * @param fxmlPath Le chemin du fichier FXML de destination.
     */
    private void navigateTo(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();
            Stage stage = (Stage) actiontarget.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Ouvre une nouvelle fenêtre avec la page FXML spécifiée et un titre donné.
     * @param fxmlPath Le chemin du fichier FXML à charger.
     * @param title Le titre de la fenêtre.
     */
    private void openWindow(String fxmlPath, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle(title);
            Scene scene = new Scene(root, 400, 400);
            stage.setScene(scene);
            stage.setMinWidth(400);
            stage.setMinHeight(400);
            stage.setMaxWidth(400);
            stage.setMaxHeight(400);
            stage.setResizable(false);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
