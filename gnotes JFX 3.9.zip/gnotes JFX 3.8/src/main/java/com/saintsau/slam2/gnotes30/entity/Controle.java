package com.saintsau.slam2.gnotes30.entity;

import jakarta.persistence.*;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Entité représentant un contrôle dans l'application.
 * Un contrôle est associé à un étudiant, un professeur, une matière,
 * et contient des informations comme la note, le type, le coefficient et la date.
 */
@Entity
@Table(name = "controles")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Controle {

    private Long id;              // Identifiant unique du contrôle
    private Etudiant etudiant;    // Étudiant ayant passé le contrôle
    private User professeur;      // Professeur ayant créé ou corrigé le contrôle
    private Matiere matiere;      // Matière concernée par le contrôle
    private int coefficient;      // Coefficient de pondération
    private String type;          // Type du contrôle (ex : DS, TP, Oral)
    private float note;           // Note obtenue par l'étudiant
    private Date dateControle;    // Date à laquelle le contrôle a eu lieu

    /**
     * Retourne l'identifiant du contrôle.
     * @return identifiant unique
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Retourne l'étudiant associé à ce contrôle.
     * @return étudiant concerné
     */
    @ManyToOne
    @JoinColumn(name = "etudiant_id", nullable = false)
    @JsonBackReference(value = "etudiant-controle")
    public Etudiant getEtudiant() {
        return etudiant;
    }

    public void setEtudiant(Etudiant etudiant) {
        this.etudiant = etudiant;
    }

    /**
     * Retourne le professeur associé à ce contrôle.
     * @return professeur concerné
     */
    @ManyToOne
    @JoinColumn(name = "professeur_id", nullable = false)
    @JsonBackReference(value = "professeur-controle")
    public User getProfesseur() {
        return professeur;
    }

    public void setProfesseur(User professeur) {
        this.professeur = professeur;
    }

    /**
     * Retourne la matière associée à ce contrôle.
     * @return matière concernée
     */
    @ManyToOne
    @JoinColumn(name = "matiere_id", nullable = false)
    @JsonBackReference(value = "matiere-controle")
    public Matiere getMatiere() {
        return matiere;
    }

    public void setMatiere(Matiere matiere) {
        this.matiere = matiere;
    }

    /**
     * Retourne le coefficient du contrôle.
     * @return coefficient
     */
    @Column(name = "coefficient", nullable = false)
    public int getCoefficient() {
        return coefficient;
    }

    public void setCoefficient(int coefficient) {
        this.coefficient = coefficient;
    }

    /**
     * Retourne le type du contrôle (DS, TP, etc.).
     * @return type de contrôle
     */
    @Column(name = "type", nullable = false)
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    /**
     * Retourne la note obtenue à ce contrôle.
     * @return note du contrôle
     */
    @Column(name = "note", nullable = false)
    public float getNote() {
        return note;
    }

    public void setNote(float note) {
        this.note = note;
    }

    /**
     * Retourne la date du contrôle.
     * @return date du contrôle
     */
    @Column(name = "date_controle", nullable = false)
    @Temporal(TemporalType.DATE)
    public Date getDateControle() {
        return dateControle;
    }

    public void setDateControle(Date dateControle) {
        this.dateControle = dateControle;
    }
}
