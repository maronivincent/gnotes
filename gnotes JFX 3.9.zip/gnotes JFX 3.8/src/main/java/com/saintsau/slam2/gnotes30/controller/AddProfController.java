package com.saintsau.slam2.gnotes30.controller;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

/**
 * Contrôleur pour ajouter un professeur dans l'application.
 * Cette classe gère l'interface utilisateur permettant de saisir les informations d'un professeur,
 * telles que son nom et la matière qu'il enseigne.
 */
public class AddProfController {

    @FXML
    private TextField nameField;  // Champ pour saisir le nom du professeur

    @FXML
    private TextField subjectField;  // Champ pour saisir la matière enseignée par le professeur

    /**
     * Méthode appelée lorsque l'utilisateur clique pour enregistrer un professeur.
     * Elle récupère les informations saisies par l'utilisateur dans les champs du formulaire,
     * effectue une vérification pour s'assurer que tous les champs sont remplis,
     * et imprime les informations du professeur dans la console.
     * Si tous les champs sont remplis, le professeur est ajouté et les champs sont réinitialisés.
     */
    @FXML
    private void saveProfessor() {
        // Récupère les valeurs des champs de saisie
        String name = nameField.getText();
        String subject = subjectField.getText();

        // Vérifie si tous les champs sont remplis
        if (name.isEmpty() || subject.isEmpty()) {
            System.out.println("Tous les champs doivent être remplis !");
            return; // Arrête la méthode si un champ est vide
        }

        // Affiche les informations du professeur ajouté (en pratique, cela pourrait être sauvegardé dans une base de données)
        System.out.println("Professeur ajouté : " + name + ", Matière : " + subject);

        // Optionnellement, réinitialise les champs après l'ajout du professeur
        nameField.clear();
        subjectField.clear();
    }
}
