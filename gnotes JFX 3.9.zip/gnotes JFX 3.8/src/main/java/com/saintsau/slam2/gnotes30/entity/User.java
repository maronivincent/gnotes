package com.saintsau.slam2.gnotes30.entity;

import jakarta.persistence.*;

/**
 * Entité représentant un utilisateur dans l'application.
 * Cette classe contient les informations de l'utilisateur, telles que son identifiant,
 * son nom d'utilisateur, son mot de passe et son statut d'activation.
 */
@Entity
@Table(name = "users")
public class User {

    private Long id;           // Clé primaire
    private String username;   // Nom d'utilisateur
    private String password;   // Mot de passe
    private boolean enabled;   // Statut activé de l'utilisateur

    /**
     * Constructeur par défaut requis par JPA.
     */
    public User() {
        super();
    }

    /**
     * Constructeur avec les informations de base de l'utilisateur.
     * @param username Le nom d'utilisateur
     * @param password Le mot de passe
     * @param enabled Le statut de l'utilisateur (actif ou non)
     */
    public User(String username, String password, boolean enabled) {
        this.username = username;
        this.password = password;
        this.enabled = enabled;
    }

    /**
     * Constructeur uniquement avec le nom d'utilisateur.
     * @param username Le nom d'utilisateur
     */
    public User(String username) {
        this.username = username;
    }

    /**
     * Retourne l'identifiant unique de l'utilisateur.
     * @return id L'identifiant de l'utilisateur
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Retourne le nom d'utilisateur.
     * @return username Le nom d'utilisateur
     */
    @Column(name = "username", nullable = false, unique = true)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Retourne le mot de passe de l'utilisateur.
     * @return password Le mot de passe
     */
    @Column(name = "password", nullable = false)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Retourne le statut activé de l'utilisateur.
     * @return enabled True si l'utilisateur est activé, sinon false
     */
    @Column(name = "enabled", nullable = false)
    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * Retourne une représentation sous forme de chaîne de caractères de l'utilisateur.
     * @return Représentation sous forme de chaîne de caractères de l'utilisateur
     */
    @Override
    public String toString() {
        return "User{id=" + id + ", username='" + username + "', enabled=" + enabled + "}";
    }
}
