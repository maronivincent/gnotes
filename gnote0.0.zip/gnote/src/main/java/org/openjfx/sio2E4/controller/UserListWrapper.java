package org.openjfx.sio2E4.controller;

import org.openjfx.sio2E4.User;

import java.util.List;

public class UserListWrapper {
    private List<User> users;

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }
}
