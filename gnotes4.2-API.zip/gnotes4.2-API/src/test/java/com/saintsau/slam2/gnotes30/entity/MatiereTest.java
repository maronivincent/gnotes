package com.saintsau.slam2.gnotes30.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class MatiereTest {

    private Matiere matiere;
    private Controle controle1;
    private Controle controle2;
    private Set<Controle> controles;

    @BeforeEach
    void setUp() {
        matiere = new Matiere();
        controle1 = new Controle();
        controle2 = new Controle();
        controles = new HashSet<>();
        controles.add(controle1);
        controles.add(controle2);
    }

    @Test
    void testId() {
        matiere.setId(1L);
        assertThat(matiere.getId()).isEqualTo(1L);
    }

    @Test
    void testIntitule() {
        matiere.setIntitule("Mathématiques");
        assertThat(matiere.getIntitule()).isEqualTo("Mathématiques");
    }

    @Test
    void testControles() {
        matiere.setControle(controles);
        assertThat(matiere.getControle()).containsExactlyInAnyOrder(controle1, controle2);
    }

    @Test
    void testConstructorWithIntitule() {
        Matiere m = new Matiere("Informatique");
        assertThat(m.getIntitule()).isEqualTo("Informatique");
    }

    @Test
    void testEmptyConstructor() {
        Matiere m = new Matiere();
        assertThat(m).isNotNull();
    }
}
