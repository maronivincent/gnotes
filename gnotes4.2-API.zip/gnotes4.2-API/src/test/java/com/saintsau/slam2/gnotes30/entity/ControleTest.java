package com.saintsau.slam2.gnotes30.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.assertj.core.api.Assertions.assertThat;

class ControleTest {

    private Controle controle;
    private Etudiant etudiant;
    private User professeur;
    private Matiere matiere;

    @BeforeEach
    void setUp() {
        controle = new Controle();
        etudiant = new Etudiant();
        professeur = new User();
        matiere = new Matiere();
    }

    @Test
    void testId() {
        controle.setId(10L);
        assertThat(controle.getId()).isEqualTo(10L);
    }

    @Test
    void testEtudiant() {
        etudiant.setNumero(1L);
        controle.setEtudiant(etudiant);
        assertThat(controle.getEtudiant()).isEqualTo(etudiant);
    }

    @Test
    void testProfesseur() {
        professeur.setId(2L);
        controle.setProfesseur(professeur);
        assertThat(controle.getProfesseur()).isEqualTo(professeur);
    }

    @Test
    void testMatiere() {
        matiere.setId(3L);
        controle.setMatiere(matiere);
        assertThat(controle.getMatiere()).isEqualTo(matiere);
    }

    @Test
    void testCoefficient() {
        controle.setCoefficient(4);
        assertThat(controle.getCoefficient()).isEqualTo(4);
    }

    @Test
    void testType() {
        controle.setType("DS");
        assertThat(controle.getType()).isEqualTo("DS");
    }

    @Test
    void testNote() {
        controle.setNote(18.5f);
        assertThat(controle.getNote()).isEqualTo(18.5f);
    }

    @Test
    void testDateControle() {
        Date now = new Date();
        controle.setDateControle(now);
        assertThat(controle.getDateControle()).isEqualTo(now);
    }
}
