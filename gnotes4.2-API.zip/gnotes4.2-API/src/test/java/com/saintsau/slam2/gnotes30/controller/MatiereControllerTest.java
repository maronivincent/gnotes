package com.saintsau.slam2.gnotes30.controller;

import com.saintsau.slam2.gnotes30.entity.Matiere;
import com.saintsau.slam2.gnotes30.service.MatiereService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class MatiereControllerTest {

    private MatiereService matiereService;
    private MatiereController controller;

    @BeforeEach
    void setUp() {
        matiereService = mock(MatiereService.class);
        controller = new MatiereController(matiereService);
    }

    @Test
    void testNewMatiere() {
        Matiere matiere = new Matiere();
        matiere.setId(1L);
        matiere.setIntitule("Mathématiques");

        when(matiereService.saveMatiere(any(Matiere.class))).thenReturn(matiere);

        EntityModel<Matiere> result = controller.newMatiere(matiere);

        assertThat(result.getContent().getIntitule()).isEqualTo("Mathématiques");
        verify(matiereService).saveMatiere(matiere);
    }

    @Test
    void testGetAllMatieres() {
        Matiere m1 = new Matiere();
        m1.setId(1L);
        Matiere m2 = new Matiere();
        m2.setId(2L);

        List<Matiere> matieres = Arrays.asList(m1, m2);
        when(matiereService.findAllMatiere()).thenReturn(matieres);

        CollectionModel<EntityModel<Matiere>> result = controller.all();

        assertThat(result.getContent()).hasSize(2);
        verify(matiereService).findAllMatiere();
    }

    @Test
    void testGetMatiereById() {
        Matiere matiere = new Matiere();
        matiere.setId(10L);
        matiere.setIntitule("Physique");

        when(matiereService.getMatiereById(10L)).thenReturn(matiere);

        EntityModel<Matiere> result = controller.getMatiereById(10L);

        assertThat(result.getContent().getIntitule()).isEqualTo("Physique");
        verify(matiereService).getMatiereById(10L);
    }

    @Test
    void testUpdateMatiere() {
        Matiere updated = new Matiere();
        updated.setId(5L);
        updated.setIntitule("Informatique");

        when(matiereService.updateMatiere(eq(5L), any(Matiere.class))).thenReturn(updated);

        EntityModel<Matiere> result = controller.updateMatiere(5L, updated);

        assertThat(result.getContent().getIntitule()).isEqualTo("Informatique");
        verify(matiereService).updateMatiere(5L, updated);
    }

    @Test
    void testDeleteMatiere() {
        Matiere matiere = new Matiere();
        matiere.setId(7L);
        matiere.setIntitule("Histoire");

        when(matiereService.deleteMatiere(7L)).thenReturn(matiere);

        EntityModel<Map<String, Object>> result = controller.deleteMatiere(7L);

        assertThat(result.getContent()).containsKeys("message", "matiere");
        assertThat(((Matiere) result.getContent().get("matiere")).getIntitule()).isEqualTo("Histoire");

        verify(matiereService).deleteMatiere(7L);
    }
}
