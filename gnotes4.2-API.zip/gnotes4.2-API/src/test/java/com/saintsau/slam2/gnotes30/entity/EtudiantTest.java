package com.saintsau.slam2.gnotes30.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class EtudiantTest {

    private Etudiant etudiant;
    private Controle controle1;
    private Controle controle2;
    private Set<Controle> controles;

    @BeforeEach
    void setUp() {
        etudiant = new Etudiant();
        controle1 = new Controle();
        controle2 = new Controle();
        controles = new HashSet<>();
        controles.add(controle1);
        controles.add(controle2);
    }

    @Test
    void testNom() {
        etudiant.setNom("Dupont");
        assertThat(etudiant.getNom()).isEqualTo("Dupont");
    }

    @Test
    void testPrenom() {
        etudiant.setPrenom("Jean");
        assertThat(etudiant.getPrenom()).isEqualTo("Jean");
    }

    @Test
    void testNumero() {
        etudiant.setNumero(123L);
        assertThat(etudiant.getNumero()).isEqualTo(123L);
    }

    @Test
    void testControles() {
        etudiant.setControles(controles);
        assertThat(etudiant.getControles()).containsExactlyInAnyOrder(controle1, controle2);
    }

    @Test
    void testConstructorWithNomPrenomNumeroControles() {
        Etudiant e = new Etudiant("Durand", "Paul", 456L, controles);
        assertThat(e.getNom()).isEqualTo("Durand");
        assertThat(e.getPrenom()).isEqualTo("Paul");
        assertThat(e.getNumero()).isEqualTo(456L);
        assertThat(e.getControles()).containsExactlyInAnyOrder(controle1, controle2);
    }

    @Test
    void testConstructorWithNomPrenomControles() {
        Etudiant e = new Etudiant("Martin", "Alice", controles);
        assertThat(e.getNom()).isEqualTo("Martin");
        assertThat(e.getPrenom()).isEqualTo("Alice");
        assertThat(e.getControles()).containsExactlyInAnyOrder(controle1, controle2);
    }

    @Test
    void testConstructorWithNomPrenom() {
        Etudiant e = new Etudiant("Lemoine", "Chloe", controles);
        assertThat(e.getNom()).isEqualTo("Lemoine");
        assertThat(e.getPrenom()).isEqualTo("Chloe");
    }
}
