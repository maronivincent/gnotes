package com.saintsau.slam2.gnotes30.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

import java.util.Arrays;
import java.util.Optional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.saintsau.slam2.gnotes30.entity.Etudiant;
import com.saintsau.slam2.gnotes30.service.EtudiantService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(EtudiantController.class)
public class EtudiantControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EtudiantService etudiantService;

    private Etudiant etudiant;

    @BeforeEach
    void setUp() {
        etudiant = new Etudiant();
        etudiant.setNumero(1L);
        etudiant.setNom("Dupont");
        etudiant.setPrenom("Jean");
    }

    @Test
    void testGetAllEtudiants() throws Exception {
        when(etudiantService.findAllEtudiant()).thenReturn(Arrays.asList(etudiant));

        mockMvc.perform(get("/etudiants"))
            .andDo(print())
            .andExpect(status().isOk())
            .andExpect(jsonPath("_embedded.etudiantList[0].nom").value("Dupont"));
    }

    @Test
    void testGetEtudiantById() throws Exception {
        when(etudiantService.findEtudiantById(1L)).thenReturn(etudiant);

        mockMvc.perform(get("/etudiants/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("nom").value("Dupont"));
    }

    @Test
    void testAddEtudiant() throws Exception {
        when(etudiantService.saveEtudiant(any(Etudiant.class))).thenReturn(etudiant);

        mockMvc.perform(post("/etudiants")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(etudiant)))
        .andExpect(status().isCreated())
            .andExpect(jsonPath("nom").value("Dupont"));
    }

    @Test
    void testUpdateEtudiant() throws Exception {
        Etudiant updated = new Etudiant();
        updated.setNumero(1L);
        updated.setNom("Durand");
        updated.setPrenom("Alice");

        when(etudiantService.updateEtudiant(eq(1L), any(Etudiant.class))).thenReturn(updated);

        mockMvc.perform(put("/etudiants/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(updated)))
            .andExpect(status().isOk())
            .andExpect(jsonPath("nom").value("Durand"));
    }

    @Test
    void testDeleteEtudiant() throws Exception {
        when(etudiantService.deleteById(1L)).thenReturn(etudiant);

        mockMvc.perform(delete("/etudiants/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("message").value("Etudiant supprimé: Dupont"));
    }
}
