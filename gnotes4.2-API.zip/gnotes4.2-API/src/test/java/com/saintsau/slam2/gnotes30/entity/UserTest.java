package com.saintsau.slam2.gnotes30.entity;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

class UserTest {

    private User user;
    private Controle controle1;
    private Controle controle2;
    private Set<Controle> controles;

    @BeforeEach
    void setUp() {
        user = new User();
        controle1 = new Controle();
        controle2 = new Controle();
        controles = new HashSet<>();
        controles.add(controle1);
        controles.add(controle2);
    }

    @Test
    void testId() {
        user.setId(1L);
        assertThat(user.getId()).isEqualTo(1L);
    }

    @Test
    void testUsername() {
        user.setUsername("professeur1");
        assertThat(user.getUsername()).isEqualTo("professeur1");
    }

    @Test
    void testPassword() {
        user.setPassword("securePassword");
        assertThat(user.getPassword()).isEqualTo("securePassword");
    }

    @Test
    void testEnabled() {
        user.setEnabled(true);
        assertThat(user.isEnabled()).isTrue();
    }

    @Test
    void testControles() {
        user.setControles(controles);
        assertThat(user.getControles()).containsExactlyInAnyOrder(controle1, controle2);
    }

    @Test
    void testConstructorFull() {
        User u = new User("user1", "pass123", true);
        assertThat(u.getUsername()).isEqualTo("user1");
        assertThat(u.getPassword()).isEqualTo("pass123");
        assertThat(u.isEnabled()).isTrue();
    }

    @Test
    void testConstructorWithUsername() {
        User u = new User("user2");
        assertThat(u.getUsername()).isEqualTo("user2");
    }

    @Test
    void testConstructorWithUsernameAndControles() {
        User u = new User("user3", controles);
        assertThat(u.getUsername()).isEqualTo("user3");
        assertThat(u.getControles()).containsExactlyInAnyOrder(controle1, controle2);
    }

    @Test
    void testToString() {
        user.setId(10L);
        user.setUsername("profX");
        user.setEnabled(true);
        assertThat(user.toString()).contains("User{id=10", "username='profX'", "enabled=true");
    }
}
