package com.saintsau.slam2.gnotes30.dto;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class ControleDTOTest {

    @Test
    void testConstructeurAvecArgumentsEtGetters() {
        Date date = new Date();
        ControleDTO dto = new ControleDTO(
                1L,
                "Mathématiques - Exam 1",
                2,
                "Examen",
                15.5f,
                "Jean Dupont",
                date
        );

        assertEquals(1L, dto.getId());
        assertEquals("Mathématiques - Exam 1", dto.getIntitule());
        assertEquals(2, dto.getCoefficient());
        assertEquals("Examen", dto.getType());
        assertEquals(15.5f, dto.getNote());
        assertEquals("Jean Dupont", dto.getNomEtudiant());
        assertEquals(date, dto.getDateControle());
    }

    @Test
    void testSettersEtGetters() {
        Date date = new Date();
        ControleDTO dto = new ControleDTO();

        dto.setId(2L);
        dto.setIntitule("Physique - TP");
        dto.setCoefficient(3);
        dto.setType("TP");
        dto.setNote(17.0f);
        dto.setNomEtudiant("Marie Curie");
        dto.setDateControle(date);

        assertEquals(2L, dto.getId());
        assertEquals("Physique - TP", dto.getIntitule());
        assertEquals(3, dto.getCoefficient());
        assertEquals("TP", dto.getType());
        assertEquals(17.0f, dto.getNote());
        assertEquals("Marie Curie", dto.getNomEtudiant());
        assertEquals(date, dto.getDateControle());
    }
}
