package com.saintsau.slam2.gnotes30.exeption;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ControleNotFoundExeptionTest {

    @Test
    void testControleNotFoundExeptionWithId() {
        // Arrange
        Long id = 123L;

        // Act
        ControleNotFoundExeption exception = new ControleNotFoundExeption(id);

        // Assert
        assertNotNull(exception);
        assertEquals("Could not find Controle with id: " + id, exception.getMessage());

    }
}