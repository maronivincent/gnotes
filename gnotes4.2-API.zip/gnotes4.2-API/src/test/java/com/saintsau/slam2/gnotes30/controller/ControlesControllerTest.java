package com.saintsau.slam2.gnotes30.controller;

import com.saintsau.slam2.gnotes30.entity.Controle;
import com.saintsau.slam2.gnotes30.dto.ControleDTO;
import com.saintsau.slam2.gnotes30.service.ControlesService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

public class ControlesControllerTest {

    private ControlesService controleService;
    private ControlesController controller;

    @BeforeEach
    void setUp() {
        controleService = mock(ControlesService.class);
        controller = new ControlesController(controleService);
    }

    @Test
    void testNewControle() {
        Controle controle = new Controle();
        controle.setId(1L);
        controle.setNote(15);

        when(controleService.saveControle(any(Controle.class))).thenReturn(controle);

        EntityModel<Controle> result = controller.newControle(controle);

        assertThat(result.getContent()).isEqualTo(controle);
        verify(controleService).saveControle(controle);
    }
    
    @Test
    void testGetAllControleDTOs() {
        ControleDTO dto1 = new ControleDTO();
        dto1.setId(1L);
        dto1.setNote(12);

        ControleDTO dto2 = new ControleDTO();
        dto2.setId(2L);
        dto2.setNote(17);

        List<ControleDTO> dtos = Arrays.asList(dto1, dto2);
        when(controleService.getAllControleDTOs()).thenReturn(dtos);

        List<ControleDTO> result = controller.getAllControleDTOs();

        assertThat(result).hasSize(2);
        assertThat(result).containsExactlyElementsOf(dtos);
        verify(controleService).getAllControleDTOs();
    }

    @Test
    void testAllControles() {
        Controle c1 = new Controle();
        c1.setId(1L);
        Controle c2 = new Controle();
        c2.setId(2L);

        List<Controle> controleList = Arrays.asList(c1, c2);
        when(controleService.getAllControles()).thenReturn(controleList);

        CollectionModel<EntityModel<Controle>> result = controller.all();

        assertThat(result.getContent()).hasSize(2);
        verify(controleService).getAllControles();
    }

    @Test
    void testGetControleById() {
        Controle controle = new Controle();
        controle.setId(42L);

        when(controleService.getContoleById(42L)).thenReturn(controle);

        EntityModel<Controle> result = controller.getControleById(42L);

        assertThat(result.getContent().getId()).isEqualTo(42L);
        verify(controleService).getContoleById(42L);
    }

    @Test
    void testUpdateControle() {
        Controle updated = new Controle();
        updated.setId(3L);
        updated.setNote(18);

        when(controleService.updateControle(eq(3L), any(Controle.class))).thenReturn(updated);

        EntityModel<Controle> result = controller.updateControle(3L, updated);

        assertThat(result.getContent().getNote()).isEqualTo(18);
        verify(controleService).updateControle(3L, updated);
    }

    @Test
    void testDeleteControle() {
        Controle deleted = new Controle();
        deleted.setId(4L);

        when(controleService.deleteControle(4L)).thenReturn(deleted);

        EntityModel<Map<String, Object>> result = controller.deleteControle(4L);

        assertThat(result.getContent()).containsKeys("message", "controle");
        assertThat(((Controle) result.getContent().get("controle")).getId()).isEqualTo(4L);
        verify(controleService).deleteControle(4L);
    }
}
