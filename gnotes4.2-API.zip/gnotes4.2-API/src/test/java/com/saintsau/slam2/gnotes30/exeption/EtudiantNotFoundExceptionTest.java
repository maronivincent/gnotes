package com.saintsau.slam2.gnotes30.exeption;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EtudiantNotFoundExceptionTest {

    @Test
    void testEtudiantNotFoundExceptionWithId() {
        // Arrange
        Long id = 123L;

        // Act
        EtudiantNotFoundException exception = new EtudiantNotFoundException(id);

        // Assert
        assertNotNull(exception);
        assertEquals("Could not find Etudiant with id: " + id, exception.getMessage());
    }
}
