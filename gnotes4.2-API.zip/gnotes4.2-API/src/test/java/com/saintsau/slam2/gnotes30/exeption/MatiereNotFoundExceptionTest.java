package com.saintsau.slam2.gnotes30.exeption;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MatiereNotFoundExceptionTest {

    @Test
    void testMatiereNotFoundExceptionWithId() {
        // Arrange
        Long idMatiere = 456L;

        // Act
        MatiereNotFoundException exception = new MatiereNotFoundException(idMatiere);

        // Assert
        assertNotNull(exception);
        assertEquals("Could not find Matiere with id: " + idMatiere, exception.getMessage());
    }
}
