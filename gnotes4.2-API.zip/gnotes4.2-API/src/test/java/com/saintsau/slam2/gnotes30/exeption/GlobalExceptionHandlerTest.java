package com.saintsau.slam2.gnotes30.exeption;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler globalExceptionHandler = new GlobalExceptionHandler();

    @Test
    void testHandleEtudiantNotFoundException() {
        // Arrange
        EtudiantNotFoundException exception = new EtudiantNotFoundException(123L);

        // Act
        Map<String, String> response = globalExceptionHandler.handleEtudiantNotFoundException(exception);

        // Assert
        assertNotNull(response);
        assertEquals("Could not find Etudiant with id: 123", response.get("error"));
    }

    @Test
    void testHandleMatiereNotFoundException() {
        // Arrange
        MatiereNotFoundException exception = new MatiereNotFoundException(456L);

        // Act
        Map<String, String> response = globalExceptionHandler.handleMatiereNotFoundException(exception);

        // Assert
        assertNotNull(response);
        assertEquals("Could not find Matiere with id: 456", response.get("error"));
    }

    @Test
    void testHandleGeneralException() {
        // Arrange
        Exception exception = new Exception("Some unexpected error");

        // Act
        Map<String, String> response = globalExceptionHandler.handleGeneralException(exception);

        // Assert
        assertNotNull(response);
        assertEquals("An unexpected error occurred: Some unexpected error", response.get("error"));
    }
}
