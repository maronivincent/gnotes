package com.saintsau.slam2.gnotes30.service;

import com.saintsau.slam2.gnotes30.entity.Matiere;
import com.saintsau.slam2.gnotes30.exeption.MatiereNotFoundException;
import com.saintsau.slam2.gnotes30.jpaRepository.MatiereRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class MatiereServiceTest {

    private MatiereRepository matiereRepository;
    private MatiereService matiereService;

    @BeforeEach
    void setUp() {
        matiereRepository = mock(MatiereRepository.class);
        matiereService = new MatiereService(matiereRepository);
    }

    @Test
    void testFindAllMatiere() {
        Matiere m1 = new Matiere();
        m1.setId(1L);
        Matiere m2 = new Matiere();
        m2.setId(2L);

        when(matiereRepository.findAll()).thenReturn(Arrays.asList(m1, m2));

        List<Matiere> result = matiereService.findAllMatiere();

        assertThat(result).hasSize(2);
        verify(matiereRepository).findAll();
    }

    @Test
    void testGetMatiereById_Existing() {
        Matiere matiere = new Matiere();
        matiere.setId(10L);

        when(matiereRepository.findById(10L)).thenReturn(Optional.of(matiere));

        Matiere result = matiereService.getMatiereById(10L);

        assertThat(result.getId()).isEqualTo(10L);
        verify(matiereRepository).findById(10L);
    }

    @Test
    void testGetMatiereById_NotFound() {
        when(matiereRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(MatiereNotFoundException.class, () -> matiereService.getMatiereById(99L));
        verify(matiereRepository).findById(99L);
    }

    @Test
    void testSaveMatiere() {
        Matiere matiere = new Matiere();
        matiere.setIntitule("Math");

        when(matiereRepository.save(matiere)).thenReturn(matiere);

        Matiere saved = matiereService.saveMatiere(matiere);

        assertThat(saved.getIntitule()).isEqualTo("Math");
        verify(matiereRepository).save(matiere);
    }

    @Test
    void testUpdateMatiere_Existing() {
        Matiere existing = new Matiere();
        existing.setId(1L);
        existing.setIntitule("Old");

        Matiere updated = new Matiere();
        updated.setIntitule("New");

        when(matiereRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(matiereRepository.save(existing)).thenReturn(existing);

        Matiere result = matiereService.updateMatiere(1L, updated);

        assertThat(result.getIntitule()).isEqualTo("New");
        verify(matiereRepository).findById(1L);
        verify(matiereRepository).save(existing);
    }

    @Test
    void testUpdateMatiere_NotFound() {
        when(matiereRepository.findById(123L)).thenReturn(Optional.empty());

        Matiere updated = new Matiere();
        updated.setIntitule("New");

        assertThrows(MatiereNotFoundException.class, () -> matiereService.updateMatiere(123L, updated));
        verify(matiereRepository).findById(123L);
    }

    @Test
    void testDeleteMatiere_Existing() {
        Matiere matiere = new Matiere();
        matiere.setId(5L);

        when(matiereRepository.findById(5L)).thenReturn(Optional.of(matiere));

        Matiere result = matiereService.deleteMatiere(5L);

        assertThat(result.getId()).isEqualTo(5L);
        verify(matiereRepository).findById(5L);
        verify(matiereRepository).delete(matiere);
    }

    @Test
    void testDeleteMatiere_NotFound() {
        when(matiereRepository.findById(77L)).thenReturn(Optional.empty());

        assertThrows(MatiereNotFoundException.class, () -> matiereService.deleteMatiere(77L));
        verify(matiereRepository).findById(77L);
    }
}
