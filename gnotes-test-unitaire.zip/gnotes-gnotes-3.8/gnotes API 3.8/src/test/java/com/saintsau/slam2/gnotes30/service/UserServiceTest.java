package com.saintsau.slam2.gnotes30.service;

import com.saintsau.slam2.gnotes30.entity.User;
import com.saintsau.slam2.gnotes30.exeption.UserNotFoundExeption;
import com.saintsau.slam2.gnotes30.jpaRepository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class UserServiceTest {

    private UserRepository userRepository;
    private UserService userService;

    @BeforeEach
    void setUp() {
        userRepository = mock(UserRepository.class);
        userService = new UserService(userRepository);
    }

    @Test
    void testFindAllUser() {
        User u1 = new User();
        u1.setId(1L);
        User u2 = new User();
        u2.setId(2L);

        when(userRepository.findAll()).thenReturn(Arrays.asList(u1, u2));

        List<User> users = userService.findAllUser();

        assertThat(users).hasSize(2);
        verify(userRepository).findAll();
    }

    @Test
    void testGetUserById_Existing() {
        User user = new User();
        user.setId(10L);

        when(userRepository.findById(10L)).thenReturn(Optional.of(user));

        User result = userService.getUserById(10L);

        assertThat(result.getId()).isEqualTo(10L);
        verify(userRepository).findById(10L);
    }

    @Test
    void testGetUserById_NotFound() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(UserNotFoundExeption.class, () -> userService.getUserById(99L));
        verify(userRepository).findById(99L);
    }

    @Test
    void testSaveUser() {
        User user = new User();
        user.setUsername("test");

        when(userRepository.save(user)).thenReturn(user);

        User savedUser = userService.saveUser(user);

        assertThat(savedUser.getUsername()).isEqualTo("test");
        verify(userRepository).save(user);
    }

    @Test
    void testUpdateUser_Existing() {
        User existing = new User();
        existing.setId(1L);
        existing.setUsername("old");
        existing.setPassword("123");
        existing.setEnabled(true);

        User updated = new User();
        updated.setUsername("new");
        updated.setPassword("456");
        updated.setEnabled(false);

        when(userRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(userRepository.save(any(User.class))).thenReturn(existing);

        User result = userService.updateUser(1L, updated);

        assertThat(result.getUsername()).isEqualTo("new");
        assertThat(result.getPassword()).isEqualTo("456");
        assertThat(result.isEnabled()).isFalse();
        verify(userRepository).findById(1L);
        verify(userRepository).save(existing);
    }

    @Test
    void testUpdateUser_NotFound() {
        when(userRepository.findById(123L)).thenReturn(Optional.empty());

        User updated = new User();
        assertThrows(UserNotFoundExeption.class, () -> userService.updateUser(123L, updated));
        verify(userRepository).findById(123L);
    }

    @Test
    void testDeleteUser_Existing() {
        User user = new User();
        user.setId(5L);

        when(userRepository.findById(5L)).thenReturn(Optional.of(user));

        User deletedUser = userService.deleteUser(5L);

        assertThat(deletedUser.getId()).isEqualTo(5L);
        verify(userRepository).findById(5L);
        verify(userRepository).deleteById(5L);
    }

    @Test
    void testDeleteUser_NotFound() {
        when(userRepository.findById(77L)).thenReturn(Optional.empty());

        assertThrows(UserNotFoundExeption.class, () -> userService.deleteUser(77L));
        verify(userRepository).findById(77L);
    }
}
