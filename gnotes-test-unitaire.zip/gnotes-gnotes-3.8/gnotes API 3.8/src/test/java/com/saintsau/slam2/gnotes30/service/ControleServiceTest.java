package com.saintsau.slam2.gnotes30.service;

import com.saintsau.slam2.gnotes30.entity.Controle;
import com.saintsau.slam2.gnotes30.entity.Etudiant;
import com.saintsau.slam2.gnotes30.entity.Matiere;
import com.saintsau.slam2.gnotes30.entity.User;
import com.saintsau.slam2.gnotes30.exeption.ControleNotFoundExeption;
import com.saintsau.slam2.gnotes30.jpaRepository.ControleRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ControlesServiceTest {

    @Mock
    private ControleRepository controleRepository;

    @InjectMocks
    private ControlesService controlesService;

    private Controle controle;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        Etudiant etudiant = new Etudiant("Dupont", "Jean");
        etudiant.setNumero(1L);

        User professeur = new User();
        professeur.setId(1L);

        Matiere matiere = new Matiere();
        matiere.setId(1L);

        controle = new Controle();
        controle.setId(1L);
        controle.setEtudiant(etudiant);
        controle.setProfesseur(professeur);
        controle.setMatiere(matiere);
        controle.setCoefficient(2);
        controle.setType("DS");
        controle.setNote(15.5f);
        controle.setDateControle(new Date());
    }

    @Test
    void getAllControles_ShouldReturnListOfControles() {
        when(controleRepository.findAll()).thenReturn(List.of(controle));

        List<Controle> result = controlesService.getAllControles();

        assertEquals(1, result.size());
        assertEquals("DS", result.get(0).getType());
        verify(controleRepository, times(1)).findAll();
    }

    @Test
    void getContoleById_WhenFound_ShouldReturnControle() {
        when(controleRepository.findById(1L)).thenReturn(Optional.of(controle));

        Controle result = controlesService.getContoleById(1L);

        assertNotNull(result);
        assertEquals(15.5f, result.getNote());
    }

    @Test
    void getContoleById_WhenNotFound_ShouldThrowException() {
        when(controleRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ControleNotFoundExeption.class, () -> controlesService.getContoleById(1L));
    }

    @Test
    void saveControle_ShouldReturnSavedControle() {
        when(controleRepository.save(any(Controle.class))).thenReturn(controle);

        Controle saved = controlesService.saveControle(controle);

        assertNotNull(saved);
        assertEquals(2, saved.getCoefficient());
        verify(controleRepository).save(controle);
    }

    @Test
    void updateControle_WhenFound_ShouldUpdateAndReturnControle() {
        Controle updated = new Controle();
        updated.setEtudiant(controle.getEtudiant());
        updated.setProfesseur(controle.getProfesseur());
        updated.setMatiere(controle.getMatiere());
        updated.setCoefficient(3);
        updated.setType("TP");
        updated.setNote(18.0f);
        updated.setDateControle(new Date());

        when(controleRepository.findById(1L)).thenReturn(Optional.of(controle));
        when(controleRepository.save(any(Controle.class))).thenReturn(updated);

        Controle result = controlesService.updateControle(1L, updated);

        assertEquals("TP", result.getType());
        assertEquals(3, result.getCoefficient());
        assertEquals(18.0f, result.getNote());
    }

    @Test
    void updateControle_WhenNotFound_ShouldThrowException() {
        Controle updated = new Controle();
        when(controleRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ControleNotFoundExeption.class, () -> controlesService.updateControle(1L, updated));
    }

    @Test
    void deleteControle_WhenFound_ShouldDeleteAndReturnControle() {
        when(controleRepository.findById(1L)).thenReturn(Optional.of(controle));
        doNothing().when(controleRepository).deleteById(1L);

        Controle deleted = controlesService.deleteControle(1L);

        assertNotNull(deleted);
        assertEquals(1L, deleted.getId());
        verify(controleRepository).deleteById(1L);
    }

    @Test
    void deleteControle_WhenNotFound_ShouldThrowException() {
        when(controleRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ControleNotFoundExeption.class, () -> controlesService.deleteControle(1L));
    }
}
