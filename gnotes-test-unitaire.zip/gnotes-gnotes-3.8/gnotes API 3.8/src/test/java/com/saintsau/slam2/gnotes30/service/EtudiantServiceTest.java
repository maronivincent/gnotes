package com.saintsau.slam2.gnotes30.service;

import com.saintsau.slam2.gnotes30.entity.Etudiant;
import com.saintsau.slam2.gnotes30.exeption.EtudiantNotFoundException;
import com.saintsau.slam2.gnotes30.jpaRepository.EtudiantRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EtudiantServiceTest {

    @Mock
    private EtudiantRepository etudiantRepository;

    @InjectMocks
    private EtudiantService etudiantService;

    private Etudiant etudiant;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        etudiant = new Etudiant("Dupont", "Jean");
        etudiant.setNumero(1L);
    }

    @Test
    void saveEtudiant_ShouldReturnSavedEtudiant() {
        when(etudiantRepository.save(any(Etudiant.class))).thenReturn(etudiant);

        Etudiant saved = etudiantService.saveEtudiant(etudiant);

        assertNotNull(saved);
        assertEquals("Dupont", saved.getNom());
        verify(etudiantRepository, times(1)).save(etudiant);
    }

    @Test
    void findAllEtudiant_ShouldReturnListOfEtudiants() {
        List<Etudiant> etudiants = Arrays.asList(etudiant);
        when(etudiantRepository.findAll()).thenReturn(etudiants);

        List<Etudiant> result = etudiantService.findAllEtudiant();

        assertEquals(1, result.size());
        assertEquals("Dupont", result.get(0).getNom());
        verify(etudiantRepository, times(1)).findAll();
    }

    @Test
    void findEtudiantById_WhenFound_ShouldReturnEtudiant() {
        when(etudiantRepository.findById(1L)).thenReturn(Optional.of(etudiant));

        Etudiant result = etudiantService.findEtudiantById(1L);

        assertNotNull(result);
        assertEquals("Dupont", result.getNom());
    }

    @Test
    void findEtudiantById_WhenNotFound_ShouldThrowException() {
        when(etudiantRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EtudiantNotFoundException.class, () -> etudiantService.findEtudiantById(1L));
    }

    @Test
    void deleteById_WhenFound_ShouldDeleteAndReturnEtudiant() {
        when(etudiantRepository.findById(1L)).thenReturn(Optional.of(etudiant));
        doNothing().when(etudiantRepository).deleteById(1L);

        Etudiant deleted = etudiantService.deleteById(1L);

        assertNotNull(deleted);
        assertEquals("Dupont", deleted.getNom());
        verify(etudiantRepository, times(1)).deleteById(1L);
    }

    @Test
    void deleteById_WhenNotFound_ShouldThrowException() {
        when(etudiantRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EtudiantNotFoundException.class, () -> etudiantService.deleteById(1L));
    }

    @Test
    void updateEtudiant_WhenFound_ShouldUpdateAndReturnEtudiant() {
        Etudiant updated = new Etudiant("Durand", "Jean");
        updated.setNumero(1L);

        when(etudiantRepository.findById(1L)).thenReturn(Optional.of(etudiant));
        when(etudiantRepository.save(any(Etudiant.class))).thenReturn(etudiant);

        Etudiant result = etudiantService.updateEtudiant(1L, updated);

        assertEquals("Durand", result.getNom());
        verify(etudiantRepository, times(1)).save(etudiant);
    }

    @Test
    void updateEtudiant_WhenNotFound_ShouldThrowException() {
        Etudiant updated = new Etudiant("Durand", "Jean");
        updated.setNumero(1L);

        when(etudiantRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(EtudiantNotFoundException.class, () -> etudiantService.updateEtudiant(1L, updated));
    }
}
