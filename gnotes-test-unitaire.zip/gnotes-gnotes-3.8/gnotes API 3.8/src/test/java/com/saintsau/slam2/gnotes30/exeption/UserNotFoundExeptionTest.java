package com.saintsau.slam2.gnotes30.exeption;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UserNotFoundExeptionTest {

    @Test
    void testUserNotFoundExeptionWithId() {
        // Arrange
        Long id = 789L;

        // Act
        UserNotFoundExeption exception = new UserNotFoundExeption(id);

        // Assert
        assertNotNull(exception);
        assertEquals("Could not find User with id : " + id, exception.getMessage());
    }
}
