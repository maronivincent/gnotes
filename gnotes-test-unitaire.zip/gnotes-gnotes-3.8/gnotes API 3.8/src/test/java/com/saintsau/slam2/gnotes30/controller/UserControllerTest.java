package com.saintsau.slam2.gnotes30.controller;

import com.saintsau.slam2.gnotes30.entity.User;
import com.saintsau.slam2.gnotes30.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class UserControllerTest {

    private UserService userService;
    private UserController controller;

    @BeforeEach
    void setUp() {
        userService = mock(UserService.class);
        controller = new UserController(userService);
    }

    @Test
    void testNewUser() {
        User user = new User();
        user.setId(1L);
        user.setUsername("jdoe");

        when(userService.saveUser(any(User.class))).thenReturn(user);

        EntityModel<User> result = controller.newUser(user);

        assertThat(result.getContent().getUsername()).isEqualTo("jdoe");
        verify(userService).saveUser(user);
    }

    @Test
    void testGetAllUsers() {
        User u1 = new User();
        u1.setId(1L);
        User u2 = new User();
        u2.setId(2L);

        when(userService.findAllUser()).thenReturn(List.of(u1, u2));

        CollectionModel<EntityModel<User>> result = controller.all();

        assertThat(result.getContent()).hasSize(2);
        verify(userService).findAllUser();
    }

    @Test
    void testGetUserById() {
        User user = new User();
        user.setId(42L);
        user.setUsername("alice");

        when(userService.getUserById(42L)).thenReturn(user);

        EntityModel<User> result = controller.getUserById(42L);

        assertThat(result.getContent().getUsername()).isEqualTo("alice");
        verify(userService).getUserById(42L);
    }

    @Test
    void testUpdateUser() {
        User updated = new User();
        updated.setId(99L);
        updated.setUsername("bob");

        when(userService.updateUser(eq(99L), any(User.class))).thenReturn(updated);

        EntityModel<User> result = controller.updateUser(99L, updated);

        assertThat(result.getContent().getUsername()).isEqualTo("bob");
        verify(userService).updateUser(99L, updated);
    }

    @Test
    void testDeleteUser() {
        User user = new User();
        user.setId(12L);
        user.setUsername("charlie");

        when(userService.deleteUser(12L)).thenReturn(user);

        EntityModel<Map<String, Object>> result = controller.deleteUser(12L);

        assertThat(result.getContent()).containsKeys("message", "etudiant");
        assertThat(((User) result.getContent().get("etudiant")).getUsername()).isEqualTo("charlie");
        verify(userService).deleteUser(12L);
    }
}
